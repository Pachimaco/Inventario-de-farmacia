﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FarmaciaApp
{
    public partial class Salidas : Form
    {
        string rol;
        ComboBox cboInventario, cboPersonal, cboTipo;
        TextBox txtCantidad, txtJustificacion, txtBuscar;
        DateTimePicker dtFecha;
        DataGridView tabla;
        Button btnGuardar, btnModificar, btnEliminar, btnLimpiar;
        int idSalida = 0;

        string perfil
        {
            get
            {
                return rol == "Administrador" ? "Administrador" : "Encargado";
            }
        }

        public Salidas(string rol)
        {
            this.rol = rol;
            crearFormulario();
            cargarInventario();
            cargarPersonal();
            cargarSalidas();
        }

        private void crearFormulario()
        {
            this.Text = "Salidas - FarmaBase";
            this.Size = new Size(1200, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(242, 245, 249);
            this.Font = new Font("Segoe UI", 10);

            Label titulo = new Label();
            titulo.Text = "Registro de salidas";
            titulo.Font = new Font("Segoe UI", 20, FontStyle.Bold);
            titulo.ForeColor = Color.FromArgb(35, 55, 75);
            titulo.Location = new Point(30, 20);
            titulo.AutoSize = true;
            this.Controls.Add(titulo);

            Label l1 = new Label();
            l1.Text = "Inventario:";
            l1.Location = new Point(35, 85);
            l1.AutoSize = true;
            this.Controls.Add(l1);

            cboInventario = new ComboBox();
            cboInventario.Location = new Point(35, 110);
            cboInventario.Size = new Size(430, 30);
            cboInventario.DropDownStyle = ComboBoxStyle.DropDownList;
            this.Controls.Add(cboInventario);

            Label l2 = new Label();
            l2.Text = "Personal:";
            l2.Location = new Point(500, 85);
            l2.AutoSize = true;
            this.Controls.Add(l2);

            cboPersonal = new ComboBox();
            cboPersonal.Location = new Point(500, 110);
            cboPersonal.Size = new Size(350, 30);
            cboPersonal.DropDownStyle = ComboBoxStyle.DropDownList;
            this.Controls.Add(cboPersonal);

            Label l3 = new Label();
            l3.Text = "Tipo de salida:";
            l3.Location = new Point(885, 85);
            l3.AutoSize = true;
            this.Controls.Add(l3);

            cboTipo = new ComboBox();
            cboTipo.Location = new Point(885, 110);
            cboTipo.Size = new Size(250, 30);
            cboTipo.DropDownStyle = ComboBoxStyle.DropDownList;
            cboTipo.Items.AddRange(new object[]
            {
                "Venta",
                "Caducidad",
                "Daño",
                "Consumo interno",
                "Devolucion"
            });
            this.Controls.Add(cboTipo);

            Label l4 = new Label();
            l4.Text = "Cantidad:";
            l4.Location = new Point(35, 165);
            l4.AutoSize = true;
            this.Controls.Add(l4);

            txtCantidad = new TextBox();
            txtCantidad.Location = new Point(35, 190);
            txtCantidad.Size = new Size(200, 30);
            this.Controls.Add(txtCantidad);

            Label l5 = new Label();
            l5.Text = "Fecha de salida:";
            l5.Location = new Point(280, 165);
            l5.AutoSize = true;
            this.Controls.Add(l5);

            dtFecha = new DateTimePicker();
            dtFecha.Location = new Point(280, 190);
            dtFecha.Size = new Size(250, 30);
            dtFecha.Format = DateTimePickerFormat.Custom;
            dtFecha.CustomFormat = "yyyy-MM-dd HH:mm";
            dtFecha.ShowUpDown = true;
            dtFecha.Value = DateTime.Now;
            this.Controls.Add(dtFecha);

            Label l6 = new Label();
            l6.Text = "Justificación:";
            l6.Location = new Point(575, 165);
            l6.AutoSize = true;
            this.Controls.Add(l6);

            txtJustificacion = new TextBox();
            txtJustificacion.Location = new Point(575, 190);
            txtJustificacion.Size = new Size(560, 30);
            this.Controls.Add(txtJustificacion);

            btnGuardar = crearBoton("Guardar", 35, 250);
            btnGuardar.Click += guardarSalida;
            this.Controls.Add(btnGuardar);

            btnModificar = crearBoton("Modificar", 155, 250);
            btnModificar.Click += modificarSalida;
            this.Controls.Add(btnModificar);

            btnEliminar = crearBoton("Eliminar", 275, 250);
            btnEliminar.Click += eliminarSalida;
            this.Controls.Add(btnEliminar);

            btnLimpiar = crearBoton("Limpiar", 395, 250);
            btnLimpiar.Click += limpiar;
            this.Controls.Add(btnLimpiar);

            Label l7 = new Label();
            l7.Text = "Buscar salida:";
            l7.Location = new Point(35, 315);
            l7.AutoSize = true;
            this.Controls.Add(l7);

            txtBuscar = new TextBox();
            txtBuscar.Location = new Point(155, 310);
            txtBuscar.Size = new Size(350, 30);
            txtBuscar.TextChanged += (s, e) => cargarSalidas();
            this.Controls.Add(txtBuscar);

            tabla = new DataGridView();
            tabla.Location = new Point(35, 360);
            tabla.Size = new Size(1110, 365);
            tabla.BackgroundColor = Color.White;
            tabla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tabla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tabla.MultiSelect = false;
            tabla.ReadOnly = true;
            tabla.AllowUserToAddRows = false;
            tabla.RowHeadersVisible = false;
            tabla.SelectionChanged += seleccionarSalida;
            this.Controls.Add(tabla);

            if (rol == "Encargado")
            {
                btnEliminar.Enabled = false;
            }
        }

        private Button crearBoton(string texto, int x, int y)
        {
            Button b = new Button();
            b.Text = texto;
            b.Location = new Point(x, y);
            b.Size = new Size(105, 38);
            b.FlatStyle = FlatStyle.Flat;
            b.BackColor = Color.FromArgb(35, 120, 145);
            b.ForeColor = Color.White;
            b.FlatAppearance.BorderSize = 0;
            b.Cursor = Cursors.Hand;
            return b;
        }

        private void cargarInventario()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"select i.id_inventario, m.nombre, i.lote, i.existencia
                                   from inventario i
                                   inner join medicamentos m
                                   on i.id_medicamento = m.id_medicamento
                                   order by m.nombre, i.lote";

                    MySqlCommand cmd = new MySqlCommand(sql, cn);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    cboInventario.Items.Clear();

                    while (dr.Read())
                    {
                        cboInventario.Items.Add(new InvItem(
                            Convert.ToInt32(dr["id_inventario"]),
                            dr["nombre"].ToString(),
                            dr["lote"].ToString(),
                            Convert.ToInt32(dr["existencia"])
                        ));
                    }

                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar inventario: " + ex.Message);
            }
        }

        private void cargarPersonal()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"select id_personal, nombre, apellido
                                   from personal
                                   where activo = true
                                   order by nombre, apellido";

                    MySqlCommand cmd = new MySqlCommand(sql, cn);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    cboPersonal.Items.Clear();

                    while (dr.Read())
                    {
                        cboPersonal.Items.Add(new PersItem(
                            Convert.ToInt32(dr["id_personal"]),
                            dr["nombre"].ToString() + " " + dr["apellido"].ToString()
                        ));
                    }

                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar personal: " + ex.Message);
            }
        }

        private void cargarSalidas()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"select s.id_salida,
                                          s.id_inventario,
                                          m.nombre as medicamento,
                                          i.lote,
                                          s.id_personal,
                                          concat(p.nombre, ' ', p.apellido) as personal,
                                          s.cantidad,
                                          s.fecha_salida,
                                          s.justificacion,
                                          s.tipo_salida
                                   from salidas s
                                   inner join inventario i
                                   on s.id_inventario = i.id_inventario
                                   inner join medicamentos m
                                   on i.id_medicamento = m.id_medicamento
                                   inner join personal p
                                   on s.id_personal = p.id_personal
                                   where cast(s.id_salida as char) like @buscar
                                   or m.nombre like @buscar
                                   or i.lote like @buscar
                                   or p.nombre like @buscar
                                   or s.tipo_salida like @buscar
                                   or s.justificacion like @buscar
                                   order by s.id_salida desc";

                    MySqlCommand cmd = new MySqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@buscar", "%" + txtBuscar.Text + "%");

                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    tabla.DataSource = dt;

                    tabla.Columns["id_salida"].HeaderText = "ID Salida";
                    tabla.Columns["id_inventario"].HeaderText = "ID Inventario";
                    tabla.Columns["medicamento"].HeaderText = "Medicamento";
                    tabla.Columns["lote"].HeaderText = "Lote";
                    tabla.Columns["id_personal"].HeaderText = "ID Personal";
                    tabla.Columns["personal"].HeaderText = "Personal";
                    tabla.Columns["cantidad"].HeaderText = "Cantidad";
                    tabla.Columns["fecha_salida"].HeaderText = "Fecha";
                    tabla.Columns["justificacion"].HeaderText = "Justificación";
                    tabla.Columns["tipo_salida"].HeaderText = "Tipo de salida";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar salidas: " + ex.Message);
            }
        }

        private void guardarSalida(object sender, EventArgs e)
        {
            if (!validar())
                return;

            InvItem inv = (InvItem)cboInventario.SelectedItem;
            PersItem pers = (PersItem)cboPersonal.SelectedItem;

            int cant = Convert.ToInt32(txtCantidad.Text);
            string tipo = cboTipo.SelectedItem.ToString();
            string justificacion = txtJustificacion.Text.Trim();

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    using (MySqlCommand cmd = new MySqlCommand(
                        "CALL farmacia.sp_registrar_salida(@p_id_inventario, @p_id_personal, @p_cantidad, @p_tipo, @p_justificacion)", cn))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("@p_id_inventario", inv.id);
                        cmd.Parameters.AddWithValue("@p_id_personal", pers.id);
                        cmd.Parameters.AddWithValue("@p_cantidad", cant);
                        cmd.Parameters.AddWithValue("@p_tipo", tipo);
                        cmd.Parameters.AddWithValue("@p_justificacion", justificacion);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Salida registrada correctamente.");
                cargarInventario();
                cargarSalidas();
                limpiar(null, null);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error de MySQL: " + ex.Number + "\n" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar salida: " + ex.Message);
            }
        }

        private void modificarSalida(object sender, EventArgs e)
        {
            if (idSalida == 0)
            {
                MessageBox.Show("Selecciona una salida de la tabla.");
                return;
            }

            if (!validar())
                return;

            InvItem inv = (InvItem)cboInventario.SelectedItem;
            PersItem pers = (PersItem)cboPersonal.SelectedItem;
            int cant = Convert.ToInt32(txtCantidad.Text);

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    using (MySqlTransaction tr = cn.BeginTransaction())
                    {
                        int invAnterior = 0;
                        int cantAnterior = 0;

                        string sqlAnt = @"select id_inventario, cantidad
                                          from salidas
                                          where id_salida = @id
                                          for update";

                        MySqlCommand cmdAnt = new MySqlCommand(sqlAnt, cn, tr);
                        cmdAnt.Parameters.AddWithValue("@id", idSalida);

                        using (MySqlDataReader dr = cmdAnt.ExecuteReader())
                        {
                            if (!dr.Read())
                            {
                                tr.Rollback();
                                MessageBox.Show("No se encontró la salida.");
                                return;
                            }

                            invAnterior = Convert.ToInt32(dr["id_inventario"]);
                            cantAnterior = Convert.ToInt32(dr["cantidad"]);
                        }

                        string devolver = @"update inventario
                                            set existencia = existencia + @cant
                                            where id_inventario = @inv";

                        MySqlCommand cmdDev = new MySqlCommand(devolver, cn, tr);
                        cmdDev.Parameters.AddWithValue("@cant", cantAnterior);
                        cmdDev.Parameters.AddWithValue("@inv", invAnterior);
                        cmdDev.ExecuteNonQuery();

                        string descontar = @"update inventario
                                             set existencia = existencia - @cant
                                             where id_inventario = @inv
                                             and existencia >= @cant";

                        MySqlCommand cmdDes = new MySqlCommand(descontar, cn, tr);
                        cmdDes.Parameters.AddWithValue("@cant", cant);
                        cmdDes.Parameters.AddWithValue("@inv", inv.id);

                        if (cmdDes.ExecuteNonQuery() == 0)
                        {
                            tr.Rollback();
                            MessageBox.Show("No hay suficientes unidades para aplicar la nueva salida.");
                            return;
                        }

                        string sql = @"update salidas
                                       set id_inventario = @inv,
                                           id_personal = @pers,
                                           cantidad = @cant,
                                           fecha_salida = @fecha,
                                           justificacion = @justificacion,
                                           tipo_salida = @tipo
                                       where id_salida = @id";

                        MySqlCommand cmd = new MySqlCommand(sql, cn, tr);
                        cmd.Parameters.AddWithValue("@inv", inv.id);
                        cmd.Parameters.AddWithValue("@pers", pers.id);
                        cmd.Parameters.AddWithValue("@cant", cant);
                        cmd.Parameters.AddWithValue("@fecha", dtFecha.Value);
                        cmd.Parameters.AddWithValue("@justificacion",
                            string.IsNullOrWhiteSpace(txtJustificacion.Text)
                            ? (object)DBNull.Value
                            : txtJustificacion.Text.Trim());
                        cmd.Parameters.AddWithValue("@tipo", cboTipo.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@id", idSalida);
                        cmd.ExecuteNonQuery();

                        tr.Commit();
                    }
                }

                MessageBox.Show("Salida modificada correctamente.");
                cargarInventario();
                cargarSalidas();
                limpiar(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar salida: " + ex.Message);
            }
        }

        private void eliminarSalida(object sender, EventArgs e)
        {
            if (rol != "Administrador")
            {
                MessageBox.Show("No tienes permiso para eliminar salidas.");
                return;
            }

            if (idSalida == 0)
            {
                MessageBox.Show("Selecciona una salida de la tabla.");
                return;
            }

            DialogResult r = MessageBox.Show(
                "¿Deseas eliminar esta salida? Las unidades regresarán al inventario.",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (r != DialogResult.Yes)
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    using (MySqlTransaction tr = cn.BeginTransaction())
                    {
                        int inv = 0;
                        int cant = 0;

                        string sql = @"select id_inventario, cantidad
                                       from salidas
                                       where id_salida = @id
                                       for update";

                        MySqlCommand cmd = new MySqlCommand(sql, cn, tr);
                        cmd.Parameters.AddWithValue("@id", idSalida);

                        using (MySqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (!dr.Read())
                            {
                                tr.Rollback();
                                MessageBox.Show("No se encontró la salida.");
                                return;
                            }

                            inv = Convert.ToInt32(dr["id_inventario"]);
                            cant = Convert.ToInt32(dr["cantidad"]);
                        }

                        string sqlInv = @"update inventario
                                          set existencia = existencia + @cant
                                          where id_inventario = @inv";

                        MySqlCommand cmdInv = new MySqlCommand(sqlInv, cn, tr);
                        cmdInv.Parameters.AddWithValue("@cant", cant);
                        cmdInv.Parameters.AddWithValue("@inv", inv);
                        cmdInv.ExecuteNonQuery();

                        string sqlDel = "delete from salidas where id_salida = @id";
                        MySqlCommand cmdDel = new MySqlCommand(sqlDel, cn, tr);
                        cmdDel.Parameters.AddWithValue("@id", idSalida);
                        cmdDel.ExecuteNonQuery();

                        tr.Commit();
                    }
                }

                MessageBox.Show("Salida eliminada correctamente.");
                cargarInventario();
                cargarSalidas();
                limpiar(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar salida: " + ex.Message);
            }
        }

        private void seleccionarSalida(object sender, EventArgs e)
        {
            if (tabla.SelectedRows.Count == 0)
                return;

            try
            {
                DataGridViewRow fila = tabla.SelectedRows[0];

                idSalida = Convert.ToInt32(fila.Cells["id_salida"].Value);

                int idInv = Convert.ToInt32(fila.Cells["id_inventario"].Value);
                int idPers = Convert.ToInt32(fila.Cells["id_personal"].Value);

                for (int i = 0; i < cboInventario.Items.Count; i++)
                {
                    InvItem item = (InvItem)cboInventario.Items[i];

                    if (item.id == idInv)
                    {
                        cboInventario.SelectedIndex = i;
                        break;
                    }
                }

                for (int i = 0; i < cboPersonal.Items.Count; i++)
                {
                    PersItem item = (PersItem)cboPersonal.Items[i];

                    if (item.id == idPers)
                    {
                        cboPersonal.SelectedIndex = i;
                        break;
                    }
                }

                txtCantidad.Text = fila.Cells["cantidad"].Value.ToString();

                txtJustificacion.Text =
                    fila.Cells["justificacion"].Value == DBNull.Value
                    ? ""
                    : fila.Cells["justificacion"].Value.ToString();

                cboTipo.SelectedItem = fila.Cells["tipo_salida"].Value.ToString();

                if (fila.Cells["fecha_salida"].Value != DBNull.Value)
                    dtFecha.Value = Convert.ToDateTime(fila.Cells["fecha_salida"].Value);
            }
            catch
            {
            }
        }

        private bool validar()
        {
            if (cboInventario.SelectedItem == null)
            {
                MessageBox.Show("Selecciona un registro de inventario.");
                return false;
            }

            if (cboPersonal.SelectedItem == null)
            {
                MessageBox.Show("Selecciona el personal.");
                return false;
            }

            if (cboTipo.SelectedItem == null)
            {
                MessageBox.Show("Selecciona el tipo de salida.");
                return false;
            }

            int cant;

            if (!int.TryParse(txtCantidad.Text, out cant) || cant <= 0)
            {
                MessageBox.Show("Ingresa una cantidad válida mayor a cero.");
                txtCantidad.Focus();
                return false;
            }

            if (txtJustificacion.Text.Trim().Length > 100)
            {
                MessageBox.Show("La justificación no puede superar los 100 caracteres.");
                txtJustificacion.Focus();
                return false;
            }

            return true;
        }

        private void limpiar(object sender, EventArgs e)
        {
            idSalida = 0;
            cboInventario.SelectedIndex = -1;
            cboPersonal.SelectedIndex = -1;
            cboTipo.SelectedIndex = -1;
            txtCantidad.Clear();
            txtJustificacion.Clear();
            dtFecha.Value = DateTime.Now;
            tabla.ClearSelection();
        }

        class InvItem
        {
            public int id;
            public string nombre;
            public string lote;
            public int existencia;

            public InvItem(int id, string nombre, string lote, int existencia)
            {
                this.id = id;
                this.nombre = nombre;
                this.lote = lote;
                this.existencia = existencia;
            }

            public override string ToString()
            {
                return id + " - " + nombre + " | Lote: " + lote + " | Existencia: " + existencia;
            }
        }

        class PersItem
        {
            public int id;
            public string nombre;

            public PersItem(int id, string nombre)
            {
                this.id = id;
                this.nombre = nombre;
            }

            public override string ToString()
            {
                return id + " - " + nombre;
            }
        }
    }
}