﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FarmaciaApp
{
    public partial class Medicamentos : Form
    {
        TextBox txtNombre, txtDescripcion, txtPresentacion;
        TextBox txtPrecio, txtCategoria, txtBuscar;
        DataGridView tabla;

        Button btnGuardar, btnModificar, btnEliminar, btnLimpiar;

        string rol;
        string perfil;
        int idSeleccionado = 0;

        public Medicamentos(string rol)
        {
            InitializeComponent();

            this.rol = rol;
            perfil = rol == "Administrador" ? "Administrador" : "Encargado";

            crearFormulario();
            cargarMedicamentos();

            if (rol != "Administrador")
            {
                btnGuardar.Visible = false;
                btnModificar.Visible = false;
                btnEliminar.Visible = false;

                txtNombre.ReadOnly = true;
                txtDescripcion.ReadOnly = true;
                txtPresentacion.ReadOnly = true;
                txtPrecio.ReadOnly = true;
                txtCategoria.ReadOnly = true;
            }
        }

        private void crearFormulario()
        {
            this.Text = "Medicamentos - FarmaBase";
            this.Size = new Size(1200, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(242, 245, 249);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            Label titulo = new Label();
            titulo.Text = "Gestión de medicamentos";
            titulo.Font = new Font("Segoe UI", 24, FontStyle.Bold);
            titulo.ForeColor = Color.FromArgb(30, 55, 85);
            titulo.Location = new Point(40, 25);
            titulo.AutoSize = true;
            this.Controls.Add(titulo);

            Label subtitulo = new Label();
            subtitulo.Text = "Registro y administración de medicamentos";
            subtitulo.Font = new Font("Segoe UI", 11);
            subtitulo.ForeColor = Color.FromArgb(90, 105, 120);
            subtitulo.Location = new Point(43, 75);
            subtitulo.AutoSize = true;
            this.Controls.Add(subtitulo);

            Panel datos = new Panel();
            datos.Location = new Point(40, 125);
            datos.Size = new Size(1100, 230);
            datos.BackColor = Color.White;
            this.Controls.Add(datos);

            crearEtiqueta(datos, "Nombre", 30, 25);
            txtNombre = crearTexto(datos, 30, 55, 300);

            crearEtiqueta(datos, "Descripción", 390, 25);
            txtDescripcion = crearTexto(datos, 390, 55, 300);

            crearEtiqueta(datos, "Presentación", 750, 25);
            txtPresentacion = crearTexto(datos, 750, 55, 300);

            crearEtiqueta(datos, "Precio", 30, 125);
            txtPrecio = crearTexto(datos, 30, 155, 200);

            crearEtiqueta(datos, "Categoría", 300, 125);
            txtCategoria = crearTexto(datos, 300, 155, 250);

            btnModificar = crearBoton("Modificar", 650, 95);
            btnEliminar = crearBoton("Eliminar", 850, 95);
            btnGuardar = crearBoton("Guardar", 650, 150);
            btnLimpiar = crearBoton("Limpiar", 850, 150);

            datos.Controls.Add(btnModificar);
            datos.Controls.Add(btnEliminar);
            datos.Controls.Add(btnGuardar);
            datos.Controls.Add(btnLimpiar);

            btnGuardar.Click += btnGuardar_Click;
            btnModificar.Click += btnModificar_Click;
            btnEliminar.Click += btnEliminar_Click;
            btnLimpiar.Click += btnLimpiar_Click;

            Label lblBuscar = new Label();
            lblBuscar.Text = "Buscar medicamento:";
            lblBuscar.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            lblBuscar.ForeColor = Color.FromArgb(30, 55, 85);
            lblBuscar.Location = new Point(40, 390);
            lblBuscar.AutoSize = true;
            this.Controls.Add(lblBuscar);

            txtBuscar = new TextBox();
            txtBuscar.Location = new Point(255, 387);
            txtBuscar.Size = new Size(400, 32);
            txtBuscar.Font = new Font("Segoe UI", 11);
            this.Controls.Add(txtBuscar);

            txtBuscar.TextChanged += (s, e) => cargarMedicamentos();

            tabla = new DataGridView();
            tabla.Location = new Point(40, 440);
            tabla.Size = new Size(1100, 260);
            tabla.BackgroundColor = Color.White;
            tabla.BorderStyle = BorderStyle.None;
            tabla.AllowUserToAddRows = false;
            tabla.ReadOnly = true;
            tabla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tabla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tabla.MultiSelect = false;
            tabla.RowTemplate.Height = 32;
            tabla.ColumnHeadersHeight = 40;
            tabla.EnableHeadersVisualStyles = false;

            tabla.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(49, 94, 120);
            tabla.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tabla.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);

            tabla.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            tabla.DefaultCellStyle.SelectionBackColor = Color.FromArgb(84, 171, 186);
            tabla.DefaultCellStyle.SelectionForeColor = Color.White;

            tabla.Columns.Add("id", "ID");
            tabla.Columns.Add("nombre", "Nombre");
            tabla.Columns.Add("descripcion", "Descripción");
            tabla.Columns.Add("presentacion", "Presentación");
            tabla.Columns.Add("precio", "Precio");
            tabla.Columns.Add("categoria", "Categoría");

            tabla.SelectionChanged += tabla_SelectionChanged;

            this.Controls.Add(tabla);

            Button btnVolver = crearBoton("Volver", 40, 720);
            this.Controls.Add(btnVolver);
            btnVolver.Click += (s, e) => this.Close();
        }

        private void crearEtiqueta(Panel panel, string texto, int x, int y)
        {
            Label lbl = new Label();
            lbl.Text = texto;
            lbl.Font = new Font("Segoe UI", 11);
            lbl.ForeColor = Color.FromArgb(90, 105, 120);
            lbl.Location = new Point(x, y);
            lbl.AutoSize = true;
            panel.Controls.Add(lbl);
        }

        private TextBox crearTexto(Panel panel, int x, int y, int ancho)
        {
            TextBox txt = new TextBox();
            txt.Location = new Point(x, y);
            txt.Size = new Size(ancho, 32);
            txt.Font = new Font("Segoe UI", 11);
            panel.Controls.Add(txt);
            return txt;
        }

        private Button crearBoton(string texto, int x, int y)
        {
            Button btn = new Button();
            btn.Text = texto;
            btn.Location = new Point(x, y);
            btn.Size = new Size(170, 42);
            btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btn.BackColor = Color.FromArgb(84, 171, 186);
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Cursor = Cursors.Hand;

            return btn;
        }

        private void cargarMedicamentos()
        {
            try
            {
                tabla.Rows.Clear();

                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"SELECT id_medicamento, nombre, descripcion,
                                          presentacion, precio, categoria
                                   FROM medicamentos
                                   WHERE nombre LIKE CONCAT('%', @texto, '%')
                                      OR descripcion LIKE CONCAT('%', @texto, '%')
                                   ORDER BY id_medicamento";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@texto", txtBuscar.Text);

                        using (MySqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                tabla.Rows.Add(
                                    dr["id_medicamento"],
                                    dr["nombre"],
                                    dr["descripcion"],
                                    dr["presentacion"],
                                    dr["precio"],
                                    dr["categoria"]
                                );
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al consultar medicamentos: " + ex.Message,
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tabla_SelectionChanged(object sender, EventArgs e)
        {
            if (tabla.SelectedRows.Count == 0)
                return;

            DataGridViewRow fila = tabla.SelectedRows[0];

            if (fila.Cells["id"].Value == null)
                return;

            idSeleccionado = Convert.ToInt32(fila.Cells["id"].Value);

            txtNombre.Text = fila.Cells["nombre"].Value?.ToString();
            txtDescripcion.Text = fila.Cells["descripcion"].Value?.ToString();
            txtPresentacion.Text = fila.Cells["presentacion"].Value?.ToString();
            txtPrecio.Text = fila.Cells["precio"].Value?.ToString();
            txtCategoria.Text = fila.Cells["categoria"].Value?.ToString();
        }

        private bool validarDatos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtPresentacion.Text) ||
                string.IsNullOrWhiteSpace(txtPrecio.Text))
            {
                MessageBox.Show("Completa los campos obligatorios.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!decimal.TryParse(txtPrecio.Text, out decimal precio) || precio <= 0)
            {
                MessageBox.Show("Ingresa un precio válido.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (rol != "Administrador")
                return;

            if (!validarDatos())
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"INSERT INTO medicamentos
                                   (nombre, descripcion, presentacion, precio, categoria)
                                   VALUES
                                   (@nombre, @descripcion, @presentacion, @precio, @categoria)";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
                        cmd.Parameters.AddWithValue("@descripcion", txtDescripcion.Text);
                        cmd.Parameters.AddWithValue("@presentacion", txtPresentacion.Text);
                        cmd.Parameters.AddWithValue("@precio", decimal.Parse(txtPrecio.Text));
                        cmd.Parameters.AddWithValue("@categoria", txtCategoria.Text);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Medicamento registrado correctamente.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Information);

                limpiarCampos();
                cargarMedicamentos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar el medicamento: " + ex.Message,
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (rol != "Administrador")
                return;

            if (idSeleccionado == 0)
            {
                MessageBox.Show("Selecciona un medicamento de la tabla.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!validarDatos())
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"UPDATE medicamentos
                                   SET nombre = @nombre,
                                       descripcion = @descripcion,
                                       presentacion = @presentacion,
                                       precio = @precio,
                                       categoria = @categoria
                                   WHERE id_medicamento = @id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
                        cmd.Parameters.AddWithValue("@descripcion", txtDescripcion.Text);
                        cmd.Parameters.AddWithValue("@presentacion", txtPresentacion.Text);
                        cmd.Parameters.AddWithValue("@precio", decimal.Parse(txtPrecio.Text));
                        cmd.Parameters.AddWithValue("@categoria", txtCategoria.Text);
                        cmd.Parameters.AddWithValue("@id", idSeleccionado);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Medicamento modificado correctamente.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Information);

                limpiarCampos();
                cargarMedicamentos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar el medicamento: " + ex.Message,
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (rol != "Administrador")
                return;

            if (idSeleccionado == 0)
            {
                MessageBox.Show("Selecciona un medicamento de la tabla.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Deseas eliminar este medicamento?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = "DELETE FROM medicamentos WHERE id_medicamento = @id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@id", idSeleccionado);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Medicamento eliminado correctamente.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Information);

                limpiarCampos();
                cargarMedicamentos();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1451)
                {
                    MessageBox.Show(
                        "No se puede eliminar este medicamento porque está relacionado con registros de inventario u otros movimientos.",
                        "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MessageBox.Show("Error al eliminar el medicamento: " + ex.Message,
                        "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void limpiarCampos()
        {
            idSeleccionado = 0;

            txtNombre.Clear();
            txtDescripcion.Clear();
            txtPresentacion.Clear();
            txtPrecio.Clear();
            txtCategoria.Clear();

            tabla.ClearSelection();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }
    }
}