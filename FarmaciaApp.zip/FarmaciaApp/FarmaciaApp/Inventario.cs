﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FarmaciaApp
{
    public partial class Inventario : Form
    {
        TextBox txtMedicamento, txtNombre, txtLote, txtExistencia, txtBuscar;
        DateTimePicker fechaCaducidad;
        DataGridView tabla;

        Button btnGuardar, btnModificar, btnEliminar, btnLimpiar;

        string rol, perfil;
        int idSeleccionado = 0;

        public Inventario(string rol)
        {
            InitializeComponent();

            this.rol = rol;
            perfil = rol == "Administrador" ? "Administrador" : "Encargado";

            crearFormulario();
            cargarInventario();

            if (rol != "Administrador")
            {
                btnGuardar.Visible = false;
                btnModificar.Visible = false;
                btnEliminar.Visible = false;

                txtMedicamento.ReadOnly = true;
                txtNombre.ReadOnly = true;
                txtLote.ReadOnly = true;
                txtExistencia.ReadOnly = true;
                fechaCaducidad.Enabled = false;
            }
        }

        private void crearFormulario()
        {
            this.Text = "Inventario - FarmaBase";
            this.Size = new Size(1200, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(242, 245, 249);

            Label titulo = new Label();
            titulo.Text = "Control de inventario";
            titulo.Font = new Font("Segoe UI", 22, FontStyle.Bold);
            titulo.ForeColor = Color.FromArgb(30, 55, 85);
            titulo.Location = new Point(35, 25);
            titulo.AutoSize = true;
            this.Controls.Add(titulo);

            Label subtitulo = new Label();
            subtitulo.Text = "Administración de lotes y existencias de medicamentos";
            subtitulo.Font = new Font("Segoe UI", 10);
            subtitulo.ForeColor = Color.FromArgb(90, 105, 120);
            subtitulo.Location = new Point(38, 75);
            subtitulo.AutoSize = true;
            this.Controls.Add(subtitulo);

            Panel datos = new Panel();
            datos.Location = new Point(35, 120);
            datos.Size = new Size(1110, 220);
            datos.BackColor = Color.White;
            datos.BorderStyle = BorderStyle.FixedSingle;
            this.Controls.Add(datos);

            crearEtiqueta(datos, "ID Medicamento", 25, 15);
            txtMedicamento = crearTexto(datos, 25, 43, 130);
            txtMedicamento.Leave += buscarMedicamento;

            crearEtiqueta(datos, "Nombre del medicamento", 190, 15);
            txtNombre = crearTexto(datos, 190, 43, 300);
            txtNombre.ReadOnly = true;

            crearEtiqueta(datos, "Lote", 535, 15);
            txtLote = crearTexto(datos, 535, 43, 220);

            crearEtiqueta(datos, "Existencia", 790, 15);
            txtExistencia = crearTexto(datos, 790, 43, 220);

            crearEtiqueta(datos, "Fecha de caducidad", 25, 95);

            fechaCaducidad = new DateTimePicker();
            fechaCaducidad.Location = new Point(25, 123);
            fechaCaducidad.Size = new Size(300, 32);
            fechaCaducidad.Font = new Font("Segoe UI", 11);
            fechaCaducidad.Format = DateTimePickerFormat.Short;
            datos.Controls.Add(fechaCaducidad);

            btnGuardar = crearBoton(datos, "Guardar", 370, 120);
            btnModificar = crearBoton(datos, "Modificar", 530, 120);
            btnEliminar = crearBoton(datos, "Eliminar", 690, 120);
            btnLimpiar = crearBoton(datos, "Limpiar", 850, 120);

            btnGuardar.Click += guardar;
            btnModificar.Click += modificar;
            btnEliminar.Click += eliminar;
            btnLimpiar.Click += limpiar;

            Label buscar = new Label();
            buscar.Text = "Buscar:";
            buscar.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            buscar.ForeColor = Color.FromArgb(30, 55, 85);
            buscar.Location = new Point(35, 365);
            buscar.AutoSize = true;
            this.Controls.Add(buscar);

            txtBuscar = new TextBox();
            txtBuscar.Location = new Point(100, 360);
            txtBuscar.Size = new Size(400, 30);
            txtBuscar.Font = new Font("Segoe UI", 11);
            this.Controls.Add(txtBuscar);

            txtBuscar.TextChanged += (s, e) => cargarInventario();

            tabla = new DataGridView();
            tabla.Location = new Point(35, 410);
            tabla.Size = new Size(1110, 320);
            tabla.BackgroundColor = Color.White;
            tabla.BorderStyle = BorderStyle.None;
            tabla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tabla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tabla.MultiSelect = false;
            tabla.ReadOnly = true;
            tabla.AllowUserToAddRows = false;
            tabla.RowHeadersVisible = false;
            tabla.Font = new Font("Segoe UI", 10);

            tabla.ColumnHeadersDefaultCellStyle.BackColor =
                Color.FromArgb(49, 94, 120);

            tabla.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tabla.ColumnHeadersDefaultCellStyle.Font =
                new Font("Segoe UI", 10, FontStyle.Bold);

            tabla.EnableHeadersVisualStyles = false;
            tabla.SelectionChanged += seleccionarFila;

            this.Controls.Add(tabla);
        }

        private void crearEtiqueta(Panel panel, string texto, int x, int y)
        {
            Label lbl = new Label();
            lbl.Text = texto;
            lbl.Location = new Point(x, y);
            lbl.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lbl.ForeColor = Color.FromArgb(30, 55, 85);
            lbl.AutoSize = true;
            panel.Controls.Add(lbl);
        }

        private TextBox crearTexto(Panel panel, int x, int y, int ancho)
        {
            TextBox txt = new TextBox();
            txt.Location = new Point(x, y);
            txt.Size = new Size(ancho, 32);
            txt.Font = new Font("Segoe UI", 11);
            panel.Controls.Add(txt);
            return txt;
        }

        private Button crearBoton(Panel panel, string texto, int x, int y)
        {
            Button btn = new Button();
            btn.Text = texto;
            btn.Location = new Point(x, y);
            btn.Size = new Size(140, 38);
            btn.BackColor = Color.FromArgb(84, 171, 186);
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            panel.Controls.Add(btn);
            return btn;
        }

        private void buscarMedicamento(object sender, EventArgs e)
        {
            if (!int.TryParse(txtMedicamento.Text, out int id))
            {
                txtNombre.Clear();
                return;
            }

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = "select nombre from medicamentos where id_medicamento = @id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);

                        object resultado = cmd.ExecuteScalar();

                        txtNombre.Text = resultado == null
                            ? ""
                            : resultado.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar medicamento: " + ex.Message);
            }
        }

        private void cargarInventario()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"
                        select i.id_inventario,
                               i.id_medicamento,
                               m.nombre as medicamento,
                               i.lote,
                               i.existencia,
                               i.fecha_caducidad
                        from inventario i
                        inner join medicamentos m
                            on i.id_medicamento = m.id_medicamento
                        where m.nombre like @buscar
                           or i.lote like @buscar
                           or cast(i.id_medicamento as char) like @buscar
                        order by i.id_inventario";

                    MySqlDataAdapter da = new MySqlDataAdapter(sql, cn);
                    da.SelectCommand.Parameters.AddWithValue(
                        "@buscar", "%" + txtBuscar.Text + "%");

                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    tabla.DataSource = dt;

                    tabla.Columns["id_inventario"].HeaderText = "ID Inventario";
                    tabla.Columns["id_medicamento"].HeaderText = "ID Medicamento";
                    tabla.Columns["medicamento"].HeaderText = "Medicamento";
                    tabla.Columns["lote"].HeaderText = "Lote";
                    tabla.Columns["existencia"].HeaderText = "Existencia";
                    tabla.Columns["fecha_caducidad"].HeaderText = "Caducidad";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar inventario: " + ex.Message);
            }
        }

        private bool validarDatos()
        {
            if (string.IsNullOrWhiteSpace(txtMedicamento.Text) ||
                string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtLote.Text) ||
                string.IsNullOrWhiteSpace(txtExistencia.Text))
            {
                MessageBox.Show("Completa todos los campos.");
                return false;
            }

            if (!int.TryParse(txtMedicamento.Text, out int medicamento) ||
                medicamento <= 0)
            {
                MessageBox.Show("Ingresa un ID de medicamento válido.");
                return false;
            }

            if (!int.TryParse(txtExistencia.Text, out int existencia) ||
                existencia < 0)
            {
                MessageBox.Show("La existencia debe ser un número entero igual o mayor a cero.");
                return false;
            }

            return true;
        }

        private void guardar(object sender, EventArgs e)
        {
            if (!validarDatos()) return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"
                        insert into inventario
                        (id_medicamento, lote, existencia, fecha_caducidad)
                        values (@medicamento, @lote, @existencia, @fecha)";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue(
                            "@medicamento", int.Parse(txtMedicamento.Text));

                        cmd.Parameters.AddWithValue("@lote", txtLote.Text.Trim());

                        cmd.Parameters.AddWithValue(
                            "@existencia", int.Parse(txtExistencia.Text));

                        cmd.Parameters.AddWithValue("@fecha", fechaCaducidad.Value.Date);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Lote registrado correctamente.");
                limpiar(null, null);
                cargarInventario();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1452)
                    MessageBox.Show("El ID del medicamento no existe.");
                else
                    MessageBox.Show("Error al registrar lote: " + ex.Message);
            }
        }

        private void modificar(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Selecciona un registro.");
                return;
            }

            if (!validarDatos()) return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"
                        update inventario
                        set id_medicamento = @medicamento,
                            lote = @lote,
                            existencia = @existencia,
                            fecha_caducidad = @fecha
                        where id_inventario = @id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue(
                            "@medicamento", int.Parse(txtMedicamento.Text));

                        cmd.Parameters.AddWithValue("@lote", txtLote.Text.Trim());

                        cmd.Parameters.AddWithValue(
                            "@existencia", int.Parse(txtExistencia.Text));

                        cmd.Parameters.AddWithValue("@fecha", fechaCaducidad.Value.Date);
                        cmd.Parameters.AddWithValue("@id", idSeleccionado);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Inventario actualizado correctamente.");
                limpiar(null, null);
                cargarInventario();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1452)
                    MessageBox.Show("El ID del medicamento no existe.");
                else
                    MessageBox.Show("Error al modificar: " + ex.Message);
            }
        }

        private void eliminar(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Selecciona un registro.");
                return;
            }

            DialogResult r = MessageBox.Show(
                "¿Deseas eliminar este lote?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (r != DialogResult.Yes) return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = "delete from inventario where id_inventario = @id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@id", idSeleccionado);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Registro eliminado correctamente.");
                limpiar(null, null);
                cargarInventario();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1451)
                    MessageBox.Show("No se puede eliminar este lote porque tiene entradas o salidas relacionadas.");
                else
                    MessageBox.Show("Error al eliminar: " + ex.Message);
            }
        }

        private void seleccionarFila(object sender, EventArgs e)
        {
            if (tabla.CurrentRow == null || tabla.CurrentRow.IsNewRow) return;

            idSeleccionado = Convert.ToInt32(
                tabla.CurrentRow.Cells["id_inventario"].Value);

            txtMedicamento.Text =
                tabla.CurrentRow.Cells["id_medicamento"].Value.ToString();

            txtNombre.Text =
                tabla.CurrentRow.Cells["medicamento"].Value.ToString();

            txtLote.Text =
                tabla.CurrentRow.Cells["lote"].Value.ToString();

            txtExistencia.Text =
                tabla.CurrentRow.Cells["existencia"].Value.ToString();

            fechaCaducidad.Value = Convert.ToDateTime(
                tabla.CurrentRow.Cells["fecha_caducidad"].Value);
        }

        private void limpiar(object sender, EventArgs e)
        {
            idSeleccionado = 0;

            txtMedicamento.Clear();
            txtNombre.Clear();
            txtLote.Clear();
            txtExistencia.Clear();

            fechaCaducidad.Value = DateTime.Today;

            tabla.ClearSelection();
        }
    }
}