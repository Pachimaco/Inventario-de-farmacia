﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FarmaciaApp
{
    public partial class Entradas : Form
    {
        string rol;
        ComboBox cboInventario, cboProveedor, cboPersonal;
        TextBox txtCantidad, txtUbicacion, txtBuscar;
        DateTimePicker dtFecha;
        DataGridView tabla;
        Button btnGuardar, btnModificar, btnEliminar, btnLimpiar;
        int idEntrada = 0;

        string perfil
        {
            get
            {
                return rol == "Administrador" ? "Administrador" : "Encargado";
            }
        }

        public Entradas(string rol)
        {
            this.rol = rol;
            crearFormulario();
            cargarInventario();
            cargarProveedores();
            cargarPersonal();
            cargarEntradas();
        }

        private void crearFormulario()
        {
            this.Text = "Entradas - FarmaBase";
            this.Size = new Size(1200, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(242, 245, 249);
            this.Font = new Font("Segoe UI", 10);

            Label titulo = new Label();
            titulo.Text = "Registro de entradas";
            titulo.Font = new Font("Segoe UI", 20, FontStyle.Bold);
            titulo.ForeColor = Color.FromArgb(35, 55, 75);
            titulo.Location = new Point(30, 20);
            titulo.AutoSize = true;
            this.Controls.Add(titulo);

            Label l1 = new Label();
            l1.Text = "Inventario:";
            l1.Location = new Point(35, 85);
            l1.AutoSize = true;
            this.Controls.Add(l1);

            cboInventario = new ComboBox();
            cboInventario.Location = new Point(35, 110);
            cboInventario.Size = new Size(350, 30);
            cboInventario.DropDownStyle = ComboBoxStyle.DropDownList;
            this.Controls.Add(cboInventario);

            Label l2 = new Label();
            l2.Text = "Proveedor:";
            l2.Location = new Point(410, 85);
            l2.AutoSize = true;
            this.Controls.Add(l2);

            cboProveedor = new ComboBox();
            cboProveedor.Location = new Point(410, 110);
            cboProveedor.Size = new Size(330, 30);
            cboProveedor.DropDownStyle = ComboBoxStyle.DropDownList;
            this.Controls.Add(cboProveedor);

            Label l3 = new Label();
            l3.Text = "Personal:";
            l3.Location = new Point(785, 85);
            l3.AutoSize = true;
            this.Controls.Add(l3);

            cboPersonal = new ComboBox();
            cboPersonal.Location = new Point(785, 110);
            cboPersonal.Size = new Size(350, 30);
            cboPersonal.DropDownStyle = ComboBoxStyle.DropDownList;
            this.Controls.Add(cboPersonal);

            Label l4 = new Label();
            l4.Text = "Cantidad:";
            l4.Location = new Point(35, 165);
            l4.AutoSize = true;
            this.Controls.Add(l4);

            txtCantidad = new TextBox();
            txtCantidad.Location = new Point(35, 190);
            txtCantidad.Size = new Size(200, 30);
            this.Controls.Add(txtCantidad);

            Label l5 = new Label();
            l5.Text = "Fecha de entrada:";
            l5.Location = new Point(280, 165);
            l5.AutoSize = true;
            this.Controls.Add(l5);

            dtFecha = new DateTimePicker();
            dtFecha.Location = new Point(280, 190);
            dtFecha.Size = new Size(250, 30);
            dtFecha.Format = DateTimePickerFormat.Custom;
            dtFecha.CustomFormat = "yyyy-MM-dd HH:mm";
            dtFecha.ShowUpDown = true;
            this.Controls.Add(dtFecha);

            Label l6 = new Label();
            l6.Text = "Ubicación en estantería:";
            l6.Location = new Point(575, 165);
            l6.AutoSize = true;
            this.Controls.Add(l6);

            txtUbicacion = new TextBox();
            txtUbicacion.Location = new Point(575, 190);
            txtUbicacion.Size = new Size(300, 30);
            this.Controls.Add(txtUbicacion);

            btnGuardar = crearBoton("Guardar", 35, 250);
            btnGuardar.Click += guardarEntrada;
            this.Controls.Add(btnGuardar);

            btnModificar = crearBoton("Modificar", 155, 250);
            btnModificar.Click += modificarEntrada;
            this.Controls.Add(btnModificar);

            btnEliminar = crearBoton("Eliminar", 275, 250);
            btnEliminar.Click += eliminarEntrada;
            this.Controls.Add(btnEliminar);

            btnLimpiar = crearBoton("Limpiar", 395, 250);
            btnLimpiar.Click += limpiar;
            this.Controls.Add(btnLimpiar);

            Label l7 = new Label();
            l7.Text = "Buscar entrada:";
            l7.Location = new Point(35, 315);
            l7.AutoSize = true;
            this.Controls.Add(l7);

            txtBuscar = new TextBox();
            txtBuscar.Location = new Point(155, 310);
            txtBuscar.Size = new Size(350, 30);
            txtBuscar.TextChanged += (s, e) => cargarEntradas();
            this.Controls.Add(txtBuscar);

            tabla = new DataGridView();
            tabla.Location = new Point(35, 360);
            tabla.Size = new Size(1110, 365);
            tabla.BackgroundColor = Color.White;
            tabla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tabla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tabla.MultiSelect = false;
            tabla.ReadOnly = true;
            tabla.AllowUserToAddRows = false;
            tabla.RowHeadersVisible = false;
            tabla.SelectionChanged += seleccionarEntrada;
            this.Controls.Add(tabla);

            if (rol == "Encargado")
                btnEliminar.Enabled = false;
        }

        private Button crearBoton(string texto, int x, int y)
        {
            Button b = new Button();
            b.Text = texto;
            b.Location = new Point(x, y);
            b.Size = new Size(105, 38);
            b.FlatStyle = FlatStyle.Flat;
            b.BackColor = Color.FromArgb(35, 120, 145);
            b.ForeColor = Color.White;
            b.FlatAppearance.BorderSize = 0;
            b.Cursor = Cursors.Hand;
            return b;
        }

        private void cargarInventario()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"select i.id_inventario, m.nombre, i.lote, i.existencia
                                   from inventario i
                                   inner join medicamentos m
                                   on i.id_medicamento = m.id_medicamento
                                   order by m.nombre, i.lote";

                    MySqlCommand cmd = new MySqlCommand(sql, cn);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    cboInventario.Items.Clear();

                    while (dr.Read())
                    {
                        cboInventario.Items.Add(new InvItem(
                            Convert.ToInt32(dr["id_inventario"]),
                            dr["nombre"].ToString(),
                            dr["lote"].ToString(),
                            Convert.ToInt32(dr["existencia"])
                        ));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar inventario: " + ex.Message);
            }
        }

        private void cargarProveedores()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = "select id_proveedor, nombre from proveedores order by nombre";
                    MySqlCommand cmd = new MySqlCommand(sql, cn);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    cboProveedor.Items.Clear();

                    while (dr.Read())
                    {
                        cboProveedor.Items.Add(new ProvItem(
                            Convert.ToInt32(dr["id_proveedor"]),
                            dr["nombre"].ToString()
                        ));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar proveedores: " + ex.Message);
            }
        }

        private void cargarPersonal()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"select id_personal, nombre, apellido
                                   from personal
                                   where activo = true
                                   order by nombre, apellido";

                    MySqlCommand cmd = new MySqlCommand(sql, cn);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    cboPersonal.Items.Clear();

                    while (dr.Read())
                    {
                        cboPersonal.Items.Add(new PersItem(
                            Convert.ToInt32(dr["id_personal"]),
                            dr["nombre"].ToString() + " " + dr["apellido"].ToString()
                        ));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar personal: " + ex.Message);
            }
        }

        private void cargarEntradas()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"select e.id_entrada,
                                          e.id_inventario,
                                          m.nombre as medicamento,
                                          i.lote,
                                          e.id_proveedor,
                                          p.nombre as proveedor,
                                          e.id_personal,
                                          concat(pe.nombre, ' ', pe.apellido) as personal,
                                          e.cantidad,
                                          e.fecha_entrada,
                                          e.ubicacion_estanteria
                                   from entradas e
                                   inner join inventario i
                                   on e.id_inventario = i.id_inventario
                                   inner join medicamentos m
                                   on i.id_medicamento = m.id_medicamento
                                   inner join proveedores p
                                   on e.id_proveedor = p.id_proveedor
                                   inner join personal pe
                                   on e.id_personal = pe.id_personal
                                   where cast(e.id_entrada as char) like @buscar
                                   or m.nombre like @buscar
                                   or i.lote like @buscar
                                   or p.nombre like @buscar
                                   or pe.nombre like @buscar
                                   or e.ubicacion_estanteria like @buscar
                                   order by e.id_entrada desc";

                    MySqlCommand cmd = new MySqlCommand(sql, cn);
                    cmd.Parameters.AddWithValue("@buscar", "%" + txtBuscar.Text + "%");

                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    tabla.DataSource = dt;

                    tabla.Columns["id_entrada"].HeaderText = "ID Entrada";
                    tabla.Columns["id_inventario"].HeaderText = "ID Inventario";
                    tabla.Columns["medicamento"].HeaderText = "Medicamento";
                    tabla.Columns["lote"].HeaderText = "Lote";
                    tabla.Columns["id_proveedor"].HeaderText = "ID Proveedor";
                    tabla.Columns["proveedor"].HeaderText = "Proveedor";
                    tabla.Columns["id_personal"].HeaderText = "ID Personal";
                    tabla.Columns["personal"].HeaderText = "Personal";
                    tabla.Columns["cantidad"].HeaderText = "Cantidad";
                    tabla.Columns["fecha_entrada"].HeaderText = "Fecha";
                    tabla.Columns["ubicacion_estanteria"].HeaderText = "Estantería";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar entradas: " + ex.Message);
            }
        }

        private void guardarEntrada(object sender, EventArgs e)
        {
            if (!validar())
                return;

            InvItem inv = (InvItem)cboInventario.SelectedItem;
            ProvItem prov = (ProvItem)cboProveedor.SelectedItem;
            PersItem pers = (PersItem)cboPersonal.SelectedItem;
            int cant = Convert.ToInt32(txtCantidad.Text);

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    using (MySqlCommand cmd = new MySqlCommand(
                        "CALL farmacia.sp_registrar_entrada(@p_id_inventario, @p_id_proveedor, @p_id_personal, @p_cantidad, @p_ubicacion)", cn))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("@p_id_inventario", inv.id);
                        cmd.Parameters.AddWithValue("@p_id_proveedor", prov.id);
                        cmd.Parameters.AddWithValue("@p_id_personal", pers.id);
                        cmd.Parameters.AddWithValue("@p_cantidad", cant);
                        cmd.Parameters.AddWithValue("@p_ubicacion", txtUbicacion.Text.Trim());

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Entrada registrada correctamente.");

                cargarInventario();
                cargarEntradas();
                limpiar(null, null);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(
                    "Error de MySQL: " + ex.Number +
                    "\n" + ex.Message
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar entrada: " + ex.Message);
            }
        }

        private void modificarEntrada(object sender, EventArgs e)
        {
            if (idEntrada == 0)
            {
                MessageBox.Show("Selecciona una entrada de la tabla.");
                return;
            }

            if (!validar())
                return;

            InvItem inv = (InvItem)cboInventario.SelectedItem;
            ProvItem prov = (ProvItem)cboProveedor.SelectedItem;
            PersItem pers = (PersItem)cboPersonal.SelectedItem;
            int cant = Convert.ToInt32(txtCantidad.Text);

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    using (MySqlTransaction tr = cn.BeginTransaction())
                    {
                        int invAnterior, cantAnterior;

                        string sqlAnt = @"select id_inventario, cantidad
                                          from entradas
                                          where id_entrada = @id
                                          for update";

                        MySqlCommand cmdAnt = new MySqlCommand(sqlAnt, cn, tr);
                        cmdAnt.Parameters.AddWithValue("@id", idEntrada);

                        using (MySqlDataReader dr = cmdAnt.ExecuteReader())
                        {
                            if (!dr.Read())
                            {
                                tr.Rollback();
                                MessageBox.Show("No se encontró la entrada.");
                                return;
                            }

                            invAnterior = Convert.ToInt32(dr["id_inventario"]);
                            cantAnterior = Convert.ToInt32(dr["cantidad"]);
                        }

                        string sqlInv = @"update inventario
                                          set existencia = existencia - @cant
                                          where id_inventario = @inv
                                          and existencia >= @cant";

                        MySqlCommand cmdInv = new MySqlCommand(sqlInv, cn, tr);
                        cmdInv.Parameters.AddWithValue("@cant", cantAnterior);
                        cmdInv.Parameters.AddWithValue("@inv", invAnterior);

                        if (cmdInv.ExecuteNonQuery() == 0)
                        {
                            tr.Rollback();
                            MessageBox.Show("No se puede modificar porque las existencias ya fueron utilizadas.");
                            return;
                        }

                        string sql = @"update entradas
                                       set id_inventario = @inv,
                                           id_proveedor = @prov,
                                           id_personal = @pers,
                                           cantidad = @cant,
                                           fecha_entrada = @fecha,
                                           ubicacion_estanteria = @ubicacion
                                       where id_entrada = @id";

                        MySqlCommand cmd = new MySqlCommand(sql, cn, tr);
                        cmd.Parameters.AddWithValue("@inv", inv.id);
                        cmd.Parameters.AddWithValue("@prov", prov.id);
                        cmd.Parameters.AddWithValue("@pers", pers.id);
                        cmd.Parameters.AddWithValue("@cant", cant);
                        cmd.Parameters.AddWithValue("@fecha", dtFecha.Value);
                        cmd.Parameters.AddWithValue("@ubicacion", txtUbicacion.Text.Trim());
                        cmd.Parameters.AddWithValue("@id", idEntrada);
                        cmd.ExecuteNonQuery();

                        MySqlCommand cmdSum = new MySqlCommand(
                            @"update inventario
                              set existencia = existencia + @cant
                              where id_inventario = @inv", cn, tr);

                        cmdSum.Parameters.AddWithValue("@cant", cant);
                        cmdSum.Parameters.AddWithValue("@inv", inv.id);
                        cmdSum.ExecuteNonQuery();

                        tr.Commit();
                    }
                }

                MessageBox.Show("Entrada modificada correctamente.");
                cargarInventario();
                cargarEntradas();
                limpiar(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar entrada: " + ex.Message);
            }
        }

        private void eliminarEntrada(object sender, EventArgs e)
        {
            if (rol != "Administrador")
            {
                MessageBox.Show("No tienes permiso para eliminar entradas.");
                return;
            }

            if (idEntrada == 0)
            {
                MessageBox.Show("Selecciona una entrada de la tabla.");
                return;
            }

            DialogResult r = MessageBox.Show(
                "¿Deseas eliminar esta entrada? También se descontará del inventario.",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (r != DialogResult.Yes)
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    using (MySqlTransaction tr = cn.BeginTransaction())
                    {
                        int inv, cant;

                        string sql = @"select id_inventario, cantidad
                                       from entradas
                                       where id_entrada = @id
                                       for update";

                        MySqlCommand cmd = new MySqlCommand(sql, cn, tr);
                        cmd.Parameters.AddWithValue("@id", idEntrada);

                        using (MySqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (!dr.Read())
                            {
                                tr.Rollback();
                                MessageBox.Show("No se encontró la entrada.");
                                return;
                            }

                            inv = Convert.ToInt32(dr["id_inventario"]);
                            cant = Convert.ToInt32(dr["cantidad"]);
                        }

                        string sqlInv = @"update inventario
                                          set existencia = existencia - @cant
                                          where id_inventario = @inv
                                          and existencia >= @cant";

                        MySqlCommand cmdInv = new MySqlCommand(sqlInv, cn, tr);
                        cmdInv.Parameters.AddWithValue("@cant", cant);
                        cmdInv.Parameters.AddWithValue("@inv", inv);

                        if (cmdInv.ExecuteNonQuery() == 0)
                        {
                            tr.Rollback();
                            MessageBox.Show("No se puede eliminar porque las existencias ya fueron utilizadas.");
                            return;
                        }

                        MySqlCommand cmdDel = new MySqlCommand(
                            "delete from entradas where id_entrada = @id", cn, tr);

                        cmdDel.Parameters.AddWithValue("@id", idEntrada);
                        cmdDel.ExecuteNonQuery();

                        tr.Commit();
                    }
                }

                MessageBox.Show("Entrada eliminada correctamente.");
                cargarInventario();
                cargarEntradas();
                limpiar(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar entrada: " + ex.Message);
            }
        }

        private void seleccionarEntrada(object sender, EventArgs e)
        {
            if (tabla.SelectedRows.Count == 0)
                return;

            try
            {
                DataGridViewRow fila = tabla.SelectedRows[0];

                idEntrada = Convert.ToInt32(fila.Cells["id_entrada"].Value);

                int idInv = Convert.ToInt32(fila.Cells["id_inventario"].Value);
                int idProv = Convert.ToInt32(fila.Cells["id_proveedor"].Value);
                int idPers = Convert.ToInt32(fila.Cells["id_personal"].Value);

                for (int i = 0; i < cboInventario.Items.Count; i++)
                {
                    if (((InvItem)cboInventario.Items[i]).id == idInv)
                    {
                        cboInventario.SelectedIndex = i;
                        break;
                    }
                }

                for (int i = 0; i < cboProveedor.Items.Count; i++)
                {
                    if (((ProvItem)cboProveedor.Items[i]).id == idProv)
                    {
                        cboProveedor.SelectedIndex = i;
                        break;
                    }
                }

                for (int i = 0; i < cboPersonal.Items.Count; i++)
                {
                    if (((PersItem)cboPersonal.Items[i]).id == idPers)
                    {
                        cboPersonal.SelectedIndex = i;
                        break;
                    }
                }

                txtCantidad.Text = fila.Cells["cantidad"].Value.ToString();
                txtUbicacion.Text = fila.Cells["ubicacion_estanteria"].Value.ToString();

                if (fila.Cells["fecha_entrada"].Value != DBNull.Value)
                    dtFecha.Value = Convert.ToDateTime(fila.Cells["fecha_entrada"].Value);
            }
            catch
            {
            }
        }

        private bool validar()
        {
            if (cboInventario.SelectedItem == null)
            {
                MessageBox.Show("Selecciona un registro de inventario.");
                return false;
            }

            if (cboProveedor.SelectedItem == null)
            {
                MessageBox.Show("Selecciona un proveedor.");
                return false;
            }

            if (cboPersonal.SelectedItem == null)
            {
                MessageBox.Show("Selecciona el personal.");
                return false;
            }

            int cant;

            if (!int.TryParse(txtCantidad.Text, out cant) || cant <= 0)
            {
                MessageBox.Show("Ingresa una cantidad válida mayor a cero.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtUbicacion.Text))
            {
                MessageBox.Show("Ingresa la ubicación de estantería.");
                return false;
            }

            if (txtUbicacion.Text.Trim().Length > 20)
            {
                MessageBox.Show("La ubicación no puede superar los 20 caracteres.");
                return false;
            }

            return true;
        }

        private void limpiar(object sender, EventArgs e)
        {
            idEntrada = 0;
            cboInventario.SelectedIndex = -1;
            cboProveedor.SelectedIndex = -1;
            cboPersonal.SelectedIndex = -1;
            txtCantidad.Clear();
            txtUbicacion.Clear();
            dtFecha.Value = DateTime.Now;
            tabla.ClearSelection();
        }

        class InvItem
        {
            public int id;
            public string nombre;
            public string lote;
            public int existencia;

            public InvItem(int id, string nombre, string lote, int existencia)
            {
                this.id = id;
                this.nombre = nombre;
                this.lote = lote;
                this.existencia = existencia;
            }

            public override string ToString()
            {
                return id + " - " + nombre + " | Lote: " + lote + " | Existencia: " + existencia;
            }
        }

        class ProvItem
        {
            public int id;
            public string nombre;

            public ProvItem(int id, string nombre)
            {
                this.id = id;
                this.nombre = nombre;
            }

            public override string ToString()
            {
                return id + " - " + nombre;
            }
        }

        class PersItem
        {
            public int id;
            public string nombre;

            public PersItem(int id, string nombre)
            {
                this.id = id;
                this.nombre = nombre;
            }

            public override string ToString()
            {
                return id + " - " + nombre;
            }
        }
    }
}