﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FarmaciaApp
{
    public partial class Personal : Form
    {
        TextBox txtNombre, txtApellido;
        ComboBox cboPuesto;
        TextBox txtUsuario, txtPassword, txtBuscar;
        ComboBox cboRol;
        CheckBox chkActivo;
        DataGridView tabla;

        Button btnGuardar, btnModificar, btnEliminar, btnLimpiar;

        string rol;
        string perfil;
        int idSeleccionado = 0;

        public Personal(string rol)
        {
            InitializeComponent();

            this.rol = rol;
            perfil = rol == "Administrador" ? "Administrador" : "Encargado";

            crearFormulario();
            cargarPersonal();

            if (rol != "Administrador")
            {
                btnGuardar.Visible = false;
                btnModificar.Visible = false;
                btnEliminar.Visible = false;

                txtNombre.ReadOnly = true;
                txtApellido.ReadOnly = true;
                cboPuesto.Enabled = false;
                txtUsuario.ReadOnly = true;
                txtPassword.Visible = false;
                cboRol.Enabled = false;
                chkActivo.Enabled = false;
            }
        }

        private void crearFormulario()
        {
            this.Text = "Personal - FarmaBase";
            this.Size = new Size(1200, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(242, 245, 249);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            Label titulo = new Label();
            titulo.Text = "Gestión de personal";
            titulo.Font = new Font("Segoe UI", 24, FontStyle.Bold);
            titulo.ForeColor = Color.FromArgb(30, 55, 85);
            titulo.Location = new Point(40, 25);
            titulo.AutoSize = true;
            this.Controls.Add(titulo);

            Label subtitulo = new Label();
            subtitulo.Text = "Administración de empleados y usuarios";
            subtitulo.Font = new Font("Segoe UI", 11);
            subtitulo.ForeColor = Color.FromArgb(90, 105, 120);
            subtitulo.Location = new Point(43, 75);
            subtitulo.AutoSize = true;
            this.Controls.Add(subtitulo);

            Panel datos = new Panel();
            datos.Location = new Point(40, 125);
            datos.Size = new Size(1100, 290);
            datos.BackColor = Color.White;
            this.Controls.Add(datos);

            crearEtiqueta(datos, "Nombre", 30, 15);
            txtNombre = crearTexto(datos, 30, 43, 300);

            crearEtiqueta(datos, "Apellido", 390, 15);
            txtApellido = crearTexto(datos, 390, 43, 300);

            crearEtiqueta(datos, "Puesto", 750, 15);

            cboPuesto = new ComboBox();
            cboPuesto.Location = new Point(750, 43);
            cboPuesto.Size = new Size(300, 32);
            cboPuesto.Font = new Font("Segoe UI", 11);
            cboPuesto.DropDownStyle = ComboBoxStyle.DropDownList;

            cboPuesto.Items.AddRange(new object[]
                    {
            "Administrador",
            "Encargado",
            "Vendedor",
            "Farmaceutico",
            "Auxiliar"
                    });

            cboPuesto.SelectedIndex = 1;
            datos.Controls.Add(cboPuesto);

            crearEtiqueta(datos, "Usuario", 30, 105);
            txtUsuario = crearTexto(datos, 30, 133, 300);

            crearEtiqueta(datos, "Contraseña", 390, 105);
            txtPassword = crearTexto(datos, 390, 133, 300);
            txtPassword.UseSystemPasswordChar = true;

            crearEtiqueta(datos, "Rol", 750, 105);

            cboRol = new ComboBox();
            cboRol.Location = new Point(750, 133);
            cboRol.Size = new Size(300, 32);
            cboRol.Font = new Font("Segoe UI", 11);
            cboRol.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRol.Items.AddRange(new object[]
            {
                "Administrador",
                "Encargado",
                "Consulta"
            });
            cboRol.SelectedIndex = 1;
            datos.Controls.Add(cboRol);

            chkActivo = new CheckBox();
            chkActivo.Text = "Cuenta activa";
            chkActivo.Font = new Font("Segoe UI", 11);
            chkActivo.ForeColor = Color.FromArgb(30, 55, 85);
            chkActivo.Location = new Point(30, 205);
            chkActivo.AutoSize = true;
            chkActivo.Checked = true;
            datos.Controls.Add(chkActivo);

            btnModificar = crearBoton("Modificar", 650, 195);
            btnEliminar = crearBoton("Eliminar", 850, 195);
            btnGuardar = crearBoton("Guardar", 650, 240);
            btnLimpiar = crearBoton("Limpiar", 850, 240);

            datos.Controls.Add(btnModificar);
            datos.Controls.Add(btnEliminar);
            datos.Controls.Add(btnGuardar);
            datos.Controls.Add(btnLimpiar);

            btnGuardar.Click += btnGuardar_Click;
            btnModificar.Click += btnModificar_Click;
            btnEliminar.Click += btnEliminar_Click;
            btnLimpiar.Click += btnLimpiar_Click;

            Label lblBuscar = new Label();
            lblBuscar.Text = "Buscar empleado:";
            lblBuscar.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            lblBuscar.ForeColor = Color.FromArgb(30, 55, 85);
            lblBuscar.Location = new Point(40, 440);
            lblBuscar.AutoSize = true;
            this.Controls.Add(lblBuscar);

            txtBuscar = new TextBox();
            txtBuscar.Location = new Point(255, 437);
            txtBuscar.Size = new Size(400, 32);
            txtBuscar.Font = new Font("Segoe UI", 11);
            this.Controls.Add(txtBuscar);

            txtBuscar.TextChanged += (s, e) => cargarPersonal();

            tabla = new DataGridView();
            tabla.Location = new Point(40, 490);
            tabla.Size = new Size(1100, 210);
            tabla.BackgroundColor = Color.White;
            tabla.BorderStyle = BorderStyle.None;
            tabla.AllowUserToAddRows = false;
            tabla.ReadOnly = true;
            tabla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tabla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tabla.MultiSelect = false;
            tabla.RowTemplate.Height = 32;
            tabla.ColumnHeadersHeight = 40;
            tabla.EnableHeadersVisualStyles = false;

            tabla.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(49, 94, 120);
            tabla.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            tabla.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);

            tabla.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            tabla.DefaultCellStyle.SelectionBackColor = Color.FromArgb(84, 171, 186);
            tabla.DefaultCellStyle.SelectionForeColor = Color.White;

            tabla.Columns.Add("id", "ID");
            tabla.Columns.Add("nombre", "Nombre");
            tabla.Columns.Add("apellido", "Apellido");
            tabla.Columns.Add("puesto", "Puesto");
            tabla.Columns.Add("usuario", "Usuario");
            tabla.Columns.Add("rol", "Rol");
            tabla.Columns.Add("activo", "Estado");

            tabla.SelectionChanged += tabla_SelectionChanged;

            this.Controls.Add(tabla);

            Button btnVolver = crearBoton("Volver", 40, 720);
            this.Controls.Add(btnVolver);
            btnVolver.Click += (s, e) => this.Close();
        }

        private void crearEtiqueta(Panel panel, string texto, int x, int y)
        {
            Label lbl = new Label();
            lbl.Text = texto;
            lbl.Font = new Font("Segoe UI", 11);
            lbl.ForeColor = Color.FromArgb(90, 105, 120);
            lbl.Location = new Point(x, y);
            lbl.AutoSize = true;
            panel.Controls.Add(lbl);
        }

        private TextBox crearTexto(Panel panel, int x, int y, int ancho)
        {
            TextBox txt = new TextBox();
            txt.Location = new Point(x, y);
            txt.Size = new Size(ancho, 32);
            txt.Font = new Font("Segoe UI", 11);
            panel.Controls.Add(txt);
            return txt;
        }

        private Button crearBoton(string texto, int x, int y)
        {
            Button btn = new Button();
            btn.Text = texto;
            btn.Location = new Point(x, y);
            btn.Size = new Size(170, 42);
            btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btn.BackColor = Color.FromArgb(84, 171, 186);
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Cursor = Cursors.Hand;

            return btn;
        }

        private void cargarPersonal()
        {
            try
            {
                tabla.Rows.Clear();

                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"SELECT id_personal, nombre, apellido,
                                          puesto, usuario, rol, activo
                                   FROM personal
                                   WHERE nombre LIKE CONCAT('%', @texto, '%')
                                      OR apellido LIKE CONCAT('%', @texto, '%')
                                      OR usuario LIKE CONCAT('%', @texto, '%')
                                   ORDER BY id_personal";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@texto", txtBuscar.Text);

                        using (MySqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                tabla.Rows.Add(
                                    dr["id_personal"],
                                    dr["nombre"],
                                    dr["apellido"],
                                    dr["puesto"],
                                    dr["usuario"],
                                    dr["rol"],
                                    Convert.ToBoolean(dr["activo"]) ? "Activo" : "Inactivo"
                                );
                            }
                        }
                    }
                }

                tabla.ClearSelection();
                idSeleccionado = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al consultar personal: " + ex.Message,
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tabla_SelectionChanged(object sender, EventArgs e)
        {
            if (tabla.SelectedRows.Count == 0)
                return;

            DataGridViewRow fila = tabla.SelectedRows[0];

            if (fila.Cells["id"].Value == null)
                return;

            idSeleccionado = Convert.ToInt32(fila.Cells["id"].Value);

            txtNombre.Text = fila.Cells["nombre"].Value?.ToString();
            txtApellido.Text = fila.Cells["apellido"].Value?.ToString();
            cboPuesto.SelectedItem = fila.Cells["puesto"].Value?.ToString();
            txtUsuario.Text = fila.Cells["usuario"].Value?.ToString();

            cboRol.SelectedItem = fila.Cells["rol"].Value?.ToString();

            chkActivo.Checked = fila.Cells["activo"].Value?.ToString() == "Activo";

            txtPassword.Clear();
        }

        private bool validarDatos(bool nuevo)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtApellido.Text) ||
                cboPuesto.SelectedItem == null ||
                string.IsNullOrWhiteSpace(txtUsuario.Text) ||
                cboRol.SelectedItem == null)
            {
                MessageBox.Show("Completa todos los campos obligatorios.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (nuevo && string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Ingresa una contraseña para el nuevo usuario.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (rol != "Administrador")
                return;

            if (!validarDatos(true))
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"INSERT INTO personal
                                   (nombre, apellido, puesto, usuario, password, rol, activo)
                                   VALUES
                                   (@nombre, @apellido, @puesto, @usuario, @password, @rol, @activo)";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
                        cmd.Parameters.AddWithValue("@apellido", txtApellido.Text);
                        cmd.Parameters.AddWithValue("@puesto", cboPuesto.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@usuario", txtUsuario.Text);
                        cmd.Parameters.AddWithValue("@password", txtPassword.Text);
                        cmd.Parameters.AddWithValue("@rol", cboRol.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@activo", chkActivo.Checked);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Empleado registrado correctamente.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Information);

                limpiarCampos();
                cargarPersonal();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062)
                    MessageBox.Show("Ese nombre de usuario ya está registrado.",
                        "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    MessageBox.Show("Error al registrar: " + ex.Message,
                        "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (rol != "Administrador")
                return;

            if (idSeleccionado == 0)
            {
                MessageBox.Show("Selecciona un empleado de la tabla.");
                return;
            }

            if (!validarDatos(false))
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"UPDATE personal
                                   SET nombre = @nombre,
                                       apellido = @apellido,
                                       puesto = @puesto,
                                       usuario = @usuario,
                                       password = IF(@password = '', password, @password),
                                       rol = @rol,
                                       activo = @activo
                                   WHERE id_personal = @id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
                        cmd.Parameters.AddWithValue("@apellido", txtApellido.Text);
                        cmd.Parameters.AddWithValue("@puesto", cboPuesto.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@usuario", txtUsuario.Text);
                        cmd.Parameters.AddWithValue("@password", txtPassword.Text);
                        cmd.Parameters.AddWithValue("@rol", cboRol.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@activo", chkActivo.Checked);
                        cmd.Parameters.AddWithValue("@id", idSeleccionado);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Empleado modificado correctamente.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Information);

                limpiarCampos();
                cargarPersonal();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062)
                    MessageBox.Show("Ese nombre de usuario ya está registrado.",
                        "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    MessageBox.Show("Error al modificar: " + ex.Message,
                        "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (rol != "Administrador")
                return;

            if (idSeleccionado == 0)
            {
                MessageBox.Show("Selecciona un empleado de la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Deseas eliminar este empleado?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = "DELETE FROM personal WHERE id_personal = @id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@id", idSeleccionado);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Empleado eliminado correctamente.",
                    "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Information);

                limpiarCampos();
                cargarPersonal();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1451)
                    MessageBox.Show(
                        "No se puede eliminar este empleado porque tiene movimientos registrados. Puedes desactivar su cuenta.",
                        "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                    MessageBox.Show("Error al eliminar: " + ex.Message,
                        "FarmaBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void limpiarCampos()
        {
            idSeleccionado = 0;

            txtNombre.Clear();
            txtApellido.Clear();
            cboPuesto.SelectedIndex = 1;
            txtUsuario.Clear();
            txtPassword.Clear();

            cboRol.SelectedIndex = 1;
            chkActivo.Checked = true;

            tabla.ClearSelection();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }
    }
}