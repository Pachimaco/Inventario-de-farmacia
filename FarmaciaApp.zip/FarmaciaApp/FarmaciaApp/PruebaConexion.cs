﻿using MySql.Data.MySqlClient;

namespace FarmaciaApp
{
    public class PruebaConexion
    {
        public static void probar()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion("Administrador"))
                {
                    cn.Open();

                    MessageBox.Show(
                        "¡Conexión exitosa con MySQL!",
                        "FarmaBase",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(
                    "Error al conectar con MySQL:\n\n" +
                    "Código: " + ex.Number + "\n" +
                    "Mensaje: " + ex.Message,
                    "FarmaBase",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "FarmaBase",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
    }
}