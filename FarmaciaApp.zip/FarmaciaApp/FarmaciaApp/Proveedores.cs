﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FarmaciaApp
{
    public partial class Proveedores : Form
    {
        TextBox txtNombre, txtTelefono, txtCorreo;
        TextBox txtDireccion, txtBuscar;
        DataGridView tabla;
        Button btnGuardar, btnModificar, btnEliminar, btnLimpiar;
        Button btnMedicamentos;
        string rol;
        string perfil;
        int idSeleccionado = 0;

        public Proveedores(string rol)
        {
            InitializeComponent();

            this.rol = rol;
            perfil = rol == "Administrador" ? "Administrador" : "Encargado";

            crearFormulario();
            cargarProveedores();

            if (rol != "Administrador")
            {
                btnGuardar.Visible = false;
                btnModificar.Visible = false;
                btnEliminar.Visible = false;
                btnMedicamentos.Visible = false;

                txtNombre.ReadOnly = true;
                txtTelefono.ReadOnly = true;
                txtCorreo.ReadOnly = true;
                txtDireccion.ReadOnly = true;
            }
        }

        private void crearFormulario()
        {
            this.Text = "Proveedores - FarmaBase";
            this.Size = new Size(1200, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(242, 245, 249);

            Label titulo = new Label();
            titulo.Text = "Proveedores";
            titulo.Font = new Font("Segoe UI", 22, FontStyle.Bold);
            titulo.Location = new Point(40, 25);
            titulo.Size = new Size(400, 40);
            this.Controls.Add(titulo);

            Label subtitulo = new Label();
            subtitulo.Text = "Administración de proveedores y sus medicamentos";
            subtitulo.Font = new Font("Segoe UI", 10);
            subtitulo.ForeColor = Color.Gray;
            subtitulo.Location = new Point(43, 70);
            subtitulo.Size = new Size(500, 25);
            this.Controls.Add(subtitulo);

            Panel panel = new Panel();
            panel.Location = new Point(40, 115);
            panel.Size = new Size(1100, 260);
            panel.BackColor = Color.White;
            this.Controls.Add(panel);

            crearEtiqueta(panel, "Nombre:", 30, 25);
            txtNombre = crearTexto(panel, 30, 50, 250);

            crearEtiqueta(panel, "Teléfono:", 310, 25);
            txtTelefono = crearTexto(panel, 310, 50, 250);

            crearEtiqueta(panel, "Correo:", 30, 115);
            txtCorreo = crearTexto(panel, 30, 140, 250);

            crearEtiqueta(panel, "Dirección:", 310, 115);
            txtDireccion = crearTexto(panel, 310, 140, 250);

            btnModificar = crearBoton(panel, "Modificar", 650, 45);
            btnModificar.Click += btnModificar_Click;

            btnEliminar = crearBoton(panel, "Eliminar", 850, 45);
            btnEliminar.Click += btnEliminar_Click;

            btnGuardar = crearBoton(panel, "Guardar", 650, 105);
            btnGuardar.Click += btnGuardar_Click;

            btnLimpiar = crearBoton(panel, "Limpiar", 850, 105);
            btnLimpiar.Click += btnLimpiar_Click;

            btnMedicamentos = crearBoton(panel, "Medicamentos", 650, 175);
            btnMedicamentos.Click += btnMedicamentos_Click;

            Label lblBuscar = new Label();
            lblBuscar.Text = "Buscar proveedor:";
            lblBuscar.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblBuscar.Location = new Point(40, 390);
            lblBuscar.Size = new Size(150, 25);
            this.Controls.Add(lblBuscar);

            txtBuscar = new TextBox();
            txtBuscar.Font = new Font("Segoe UI", 11);
            txtBuscar.Location = new Point(190, 387);
            txtBuscar.Size = new Size(350, 30);
            txtBuscar.TextChanged += (s, e) => cargarProveedores();
            this.Controls.Add(txtBuscar);

            tabla = new DataGridView();
            tabla.Location = new Point(40, 435);
            tabla.Size = new Size(1100, 250);
            tabla.BackgroundColor = Color.White;
            tabla.BorderStyle = BorderStyle.None;
            tabla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tabla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tabla.MultiSelect = false;
            tabla.ReadOnly = true;
            tabla.AllowUserToAddRows = false;
            tabla.RowHeadersVisible = false;
            tabla.Font = new Font("Segoe UI", 10);
            tabla.SelectionChanged += tabla_SelectionChanged;
            this.Controls.Add(tabla);

            Button btnVolver = new Button();
            btnVolver.Text = "Volver";
            btnVolver.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btnVolver.BackColor = Color.FromArgb(40, 70, 100);
            btnVolver.ForeColor = Color.White;
            btnVolver.FlatStyle = FlatStyle.Flat;
            btnVolver.Location = new Point(990, 710);
            btnVolver.Size = new Size(150, 40);
            btnVolver.Click += (s, e) => this.Close();
            this.Controls.Add(btnVolver);
        }

        private void crearEtiqueta(Panel panel, string texto, int x, int y)
        {
            Label lbl = new Label();
            lbl.Text = texto;
            lbl.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lbl.Location = new Point(x, y);
            lbl.Size = new Size(150, 25);
            panel.Controls.Add(lbl);
        }

        private TextBox crearTexto(Panel panel, int x, int y, int ancho)
        {
            TextBox txt = new TextBox();
            txt.Font = new Font("Segoe UI", 11);
            txt.Location = new Point(x, y);
            txt.Size = new Size(ancho, 30);
            panel.Controls.Add(txt);
            return txt;
        }

        private Button crearBoton(Panel panel, string texto, int x, int y)
        {
            Button btn = new Button();
            btn.Text = texto;
            btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btn.BackColor = Color.FromArgb(20, 145, 145);
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.Location = new Point(x, y);
            btn.Size = new Size(170, 40);
            panel.Controls.Add(btn);
            return btn;
        }

        private void cargarProveedores()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"SELECT
                                   id_proveedor AS id,
                                   nombre,
                                   telefono,
                                   correo,
                                   direccion
                                   FROM proveedores
                                   WHERE nombre LIKE @buscar
                                   ORDER BY id_proveedor";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@buscar", "%" + txtBuscar.Text + "%");

                        using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            tabla.DataSource = dt;
                        }
                    }
                }

                if (tabla.Columns.Contains("id"))
                    tabla.Columns["id"].HeaderText = "ID";

                if (tabla.Columns.Contains("nombre"))
                    tabla.Columns["nombre"].HeaderText = "Nombre";

                if (tabla.Columns.Contains("telefono"))
                    tabla.Columns["telefono"].HeaderText = "Teléfono";

                if (tabla.Columns.Contains("correo"))
                    tabla.Columns["correo"].HeaderText = "Correo";

                if (tabla.Columns.Contains("direccion"))
                    tabla.Columns["direccion"].HeaderText = "Dirección";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar proveedores: " + ex.Message);
            }
        }

        private void tabla_SelectionChanged(object sender, EventArgs e)
        {
            if (tabla.CurrentRow == null)
                return;

            if (tabla.CurrentRow.Cells["id"].Value == null)
                return;

            idSeleccionado = Convert.ToInt32(tabla.CurrentRow.Cells["id"].Value);

            txtNombre.Text = tabla.CurrentRow.Cells["nombre"].Value.ToString();
            txtTelefono.Text = tabla.CurrentRow.Cells["telefono"].Value.ToString();
            txtCorreo.Text = tabla.CurrentRow.Cells["correo"].Value.ToString();
            txtDireccion.Text = tabla.CurrentRow.Cells["direccion"].Value.ToString();
        }

        private bool validarDatos()
        {
            if (txtNombre.Text.Trim() == "")
            {
                MessageBox.Show("Ingresa el nombre del proveedor.");
                txtNombre.Focus();
                return false;
            }

            return true;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (!validarDatos())
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"INSERT INTO proveedores
                                   (nombre, telefono, correo, direccion)
                                   VALUES
                                   (@nombre, @telefono, @correo, @direccion)";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", txtNombre.Text.Trim());
                        cmd.Parameters.AddWithValue("@telefono", txtTelefono.Text.Trim());
                        cmd.Parameters.AddWithValue("@correo", txtCorreo.Text.Trim());
                        cmd.Parameters.AddWithValue("@direccion", txtDireccion.Text.Trim());

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Proveedor guardado correctamente.");
                limpiarCampos();
                cargarProveedores();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar proveedor: " + ex.Message);
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Selecciona un proveedor.");
                return;
            }

            if (!validarDatos())
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = @"UPDATE proveedores
                                   SET nombre = @nombre,
                                       telefono = @telefono,
                                       correo = @correo,
                                       direccion = @direccion
                                   WHERE id_proveedor = @id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", txtNombre.Text.Trim());
                        cmd.Parameters.AddWithValue("@telefono", txtTelefono.Text.Trim());
                        cmd.Parameters.AddWithValue("@correo", txtCorreo.Text.Trim());
                        cmd.Parameters.AddWithValue("@direccion", txtDireccion.Text.Trim());
                        cmd.Parameters.AddWithValue("@id", idSeleccionado);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Proveedor modificado correctamente.");
                limpiarCampos();
                cargarProveedores();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar proveedor: " + ex.Message);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Selecciona un proveedor.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Deseas eliminar este proveedor?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion(perfil))
                {
                    cn.Open();

                    string sql = "DELETE FROM proveedores WHERE id_proveedor = @id";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@id", idSeleccionado);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Proveedor eliminado correctamente.");
                limpiarCampos();
                cargarProveedores();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1451)
                    MessageBox.Show("No se puede eliminar este proveedor porque tiene registros relacionados.");
                else
                    MessageBox.Show("Error al eliminar proveedor: " + ex.Message);
            }
        }

        private void limpiarCampos()
        {
            txtNombre.Clear();
            txtTelefono.Clear();
            txtCorreo.Clear();
            txtDireccion.Clear();

            idSeleccionado = 0;
            tabla.ClearSelection();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiarCampos();
        }

        private void btnMedicamentos_Click(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Primero selecciona un proveedor.");
                return;
            }

            VentanaMedicamentosProveedor ventana =
                new VentanaMedicamentosProveedor(idSeleccionado);

            ventana.ShowDialog();
        }
    }

    public class VentanaMedicamentosProveedor : Form
    {
        ComboBox cboMed;
        TextBox txtPrecio;
        DataGridView tablaMed;
        int idProveedor;

        public VentanaMedicamentosProveedor(int idProveedor)
        {
            this.idProveedor = idProveedor;

            crearFormulario();
            cargarCombo();
            cargarMed();
        }

        private void crearFormulario()
        {
            this.Text = "Medicamentos del proveedor";
            this.Size = new Size(650, 570);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.FromArgb(242, 245, 249);

            Label titulo = new Label();
            titulo.Text = "Medicamentos del proveedor";
            titulo.Font = new Font("Segoe UI", 17, FontStyle.Bold);
            titulo.Location = new Point(25, 20);
            titulo.Size = new Size(500, 35);
            this.Controls.Add(titulo);

            Label lblMed = new Label();
            lblMed.Text = "Medicamento:";
            lblMed.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblMed.Location = new Point(30, 75);
            lblMed.Size = new Size(150, 25);
            this.Controls.Add(lblMed);

            cboMed = new ComboBox();
            cboMed.Font = new Font("Segoe UI", 10);
            cboMed.DropDownStyle = ComboBoxStyle.DropDownList;
            cboMed.Location = new Point(30, 105);
            cboMed.Size = new Size(270, 30);
            this.Controls.Add(cboMed);

            Label lblPrecio = new Label();
            lblPrecio.Text = "Precio de compra:";
            lblPrecio.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblPrecio.Location = new Point(330, 75);
            lblPrecio.Size = new Size(180, 25);
            this.Controls.Add(lblPrecio);

            txtPrecio = new TextBox();
            txtPrecio.Font = new Font("Segoe UI", 10);
            txtPrecio.Location = new Point(330, 105);
            txtPrecio.Size = new Size(250, 30);
            this.Controls.Add(txtPrecio);

            Button btnGuardar = crearBoton("Guardar", 30, 160);
            btnGuardar.Click += btnGuardar_Click;

            Button btnModificar = crearBoton("Modificar precio", 220, 160);
            btnModificar.Click += btnModificar_Click;

            Button btnEliminar = crearBoton("Eliminar", 410, 160);
            btnEliminar.Click += btnEliminar_Click;

            tablaMed = new DataGridView();
            tablaMed.Location = new Point(30, 225);
            tablaMed.Size = new Size(550, 230);
            tablaMed.BackgroundColor = Color.White;
            tablaMed.BorderStyle = BorderStyle.None;
            tablaMed.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            tablaMed.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            tablaMed.MultiSelect = false;
            tablaMed.ReadOnly = true;
            tablaMed.AllowUserToAddRows = false;
            tablaMed.RowHeadersVisible = false;
            tablaMed.Font = new Font("Segoe UI", 10);
            tablaMed.SelectionChanged += tablaMed_SelectionChanged;
            this.Controls.Add(tablaMed);

            Button btnCerrar = crearBoton("Cerrar", 410, 475);
            btnCerrar.Click += (s, e) => this.Close();
        }

        private Button crearBoton(string texto, int x, int y)
        {
            Button btn = new Button();
            btn.Text = texto;
            btn.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            btn.BackColor = Color.FromArgb(20, 145, 145);
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.Location = new Point(x, y);
            btn.Size = new Size(170, 40);
            this.Controls.Add(btn);
            return btn;
        }

        private void cargarCombo()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion("Administrador"))
                {
                    cn.Open();

                    string sql = @"SELECT id_medicamento, nombre
                                   FROM medicamentos
                                   ORDER BY nombre";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        cboMed.Items.Clear();

                        while (dr.Read())
                        {
                            cboMed.Items.Add(new MedItem
                            {
                                id = Convert.ToInt32(dr["id_medicamento"]),
                                nombre = dr["nombre"].ToString()
                            });
                        }
                    }
                }

                cboMed.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar medicamentos: " + ex.Message);
            }
        }

        private void cargarMed()
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion("Administrador"))
                {
                    cn.Open();

                    string sql = @"SELECT
                                   m.id_medicamento AS id,
                                   m.nombre AS medicamento,
                                   mp.precio_compra AS precio
                                   FROM medicamento_proveedor mp
                                   INNER JOIN medicamentos m
                                   ON mp.id_medicamento = m.id_medicamento
                                   WHERE mp.id_proveedor = @proveedor
                                   ORDER BY m.nombre";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@proveedor", idProveedor);

                        using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            tablaMed.DataSource = dt;
                        }
                    }
                }

                if (tablaMed.Columns.Contains("id"))
                    tablaMed.Columns["id"].Visible = false;

                if (tablaMed.Columns.Contains("medicamento"))
                    tablaMed.Columns["medicamento"].HeaderText = "Medicamento";

                if (tablaMed.Columns.Contains("precio"))
                    tablaMed.Columns["precio"].HeaderText = "Precio de compra";

                tablaMed.ClearSelection();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las relaciones: " + ex.Message);
            }
        }

        private void tablaMed_SelectionChanged(object sender, EventArgs e)
        {
            if (tablaMed.CurrentRow == null)
                return;

            if (tablaMed.CurrentRow.Cells["id"].Value == null)
                return;

            int idMed = Convert.ToInt32(tablaMed.CurrentRow.Cells["id"].Value);

            foreach (MedItem item in cboMed.Items)
            {
                if (item.id == idMed)
                {
                    cboMed.SelectedItem = item;
                    break;
                }
            }

            txtPrecio.Text = tablaMed.CurrentRow.Cells["precio"].Value.ToString();
        }

        private bool validarPrecio()
        {
            decimal precio;

            if (!decimal.TryParse(txtPrecio.Text, out precio) || precio <= 0)
            {
                MessageBox.Show("Ingresa un precio de compra válido.");
                txtPrecio.Focus();
                return false;
            }

            return true;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            MedItem med = cboMed.SelectedItem as MedItem;

            if (med == null)
            {
                MessageBox.Show("Selecciona un medicamento.");
                return;
            }

            if (!validarPrecio())
                return;

            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion("Administrador"))
                {
                    cn.Open();

                    string sql = @"INSERT INTO medicamento_proveedor
                                   (id_medicamento, id_proveedor, precio_compra)
                                   VALUES
                                   (@med, @prov, @precio)";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@med", med.id);
                        cmd.Parameters.AddWithValue("@prov", idProveedor);
                        cmd.Parameters.AddWithValue("@precio", decimal.Parse(txtPrecio.Text));

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Medicamento relacionado correctamente.");
                txtPrecio.Clear();
                cboMed.SelectedIndex = -1;
                cargarMed();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062)
                    MessageBox.Show("Este medicamento ya está relacionado con el proveedor.");
                else
                    MessageBox.Show("Error al guardar la relación: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar la relación: " + ex.Message);
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (tablaMed.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una relación de la tabla.");
                return;
            }

            if (!validarPrecio())
                return;

            try
            {
                int idMed = Convert.ToInt32(tablaMed.CurrentRow.Cells["id"].Value);

                using (MySqlConnection cn = Conexion.obtenerConexion("Administrador"))
                {
                    cn.Open();

                    string sql = @"UPDATE medicamento_proveedor
                                   SET precio_compra = @precio
                                   WHERE id_medicamento = @med
                                   AND id_proveedor = @prov";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@precio", decimal.Parse(txtPrecio.Text));
                        cmd.Parameters.AddWithValue("@med", idMed);
                        cmd.Parameters.AddWithValue("@prov", idProveedor);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Precio modificado correctamente.");
                txtPrecio.Clear();
                cboMed.SelectedIndex = -1;
                cargarMed();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar el precio: " + ex.Message);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (tablaMed.CurrentRow == null)
            {
                MessageBox.Show("Selecciona una relación de la tabla.");
                return;
            }

            DialogResult respuesta = MessageBox.Show(
                "¿Deseas quitar este medicamento del proveedor?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (respuesta != DialogResult.Yes)
                return;

            try
            {
                int idMed = Convert.ToInt32(tablaMed.CurrentRow.Cells["id"].Value);

                using (MySqlConnection cn = Conexion.obtenerConexion("Administrador"))
                {
                    cn.Open();

                    string sql = @"DELETE FROM medicamento_proveedor
                                   WHERE id_medicamento = @med
                                   AND id_proveedor = @prov";

                    using (MySqlCommand cmd = new MySqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@med", idMed);
                        cmd.Parameters.AddWithValue("@prov", idProveedor);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Relación eliminada correctamente.");
                txtPrecio.Clear();
                cboMed.SelectedIndex = -1;
                cargarMed();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar la relación: " + ex.Message);
            }
        }

        private class MedItem
        {
            public int id;
            public string nombre;

            public override string ToString()
            {
                return nombre;
            }
        }
    }
}