﻿using System;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace FarmaciaApp
{
    public class Conexion
    {
        public static MySqlConnection obtenerConexion(string perfil)
        {
            string cadena = ConfigurationManager.ConnectionStrings[perfil]?.ConnectionString;

            if (string.IsNullOrEmpty(cadena))
            {
                throw new Exception("No se encontró la configuración de conexión.");
            }

            return new MySqlConnection(cadena);
        }
    }
}