﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace FarmaciaApp
{
    public partial class Menu : Form
    {
        Panel lateral, contenido;
        Label titulo, subtitulo;
        string rol;
        Dictionary<string, Button> botones = new Dictionary<string, Button>();

        public Menu(string rol)
        {
            InitializeComponent();

            this.rol = rol;

            crearMenu();
            aplicarPermisos();
        }

        private void crearMenu()
        {
            this.Text = "FarmaBase";
            this.Size = new Size(1200, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(242, 245, 249);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            lateral = new Panel();
            lateral.Size = new Size(250, 800);
            lateral.Location = new Point(0, 0);
            lateral.BackColor = Color.FromArgb(49, 94, 120);
            this.Controls.Add(lateral);

            Label logo = new Label();
            logo.Text = "FarmaBase";
            logo.Font = new Font("Segoe UI", 22, FontStyle.Bold);
            logo.ForeColor = Color.White;
            logo.Location = new Point(25, 30);
            logo.AutoSize = true;
            lateral.Controls.Add(logo);

            Label desc = new Label();
            desc.Text = "Gestión de farmacia";
            desc.Font = new Font("Segoe UI", 9);
            desc.ForeColor = Color.LightGray;
            desc.Location = new Point(28, 75);
            desc.AutoSize = true;
            lateral.Controls.Add(desc);

            Label menu = new Label();
            menu.Text = "MENÚ PRINCIPAL";
            menu.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            menu.ForeColor = Color.Silver;
            menu.Location = new Point(25, 130);
            menu.AutoSize = true;
            lateral.Controls.Add(menu);

            crearBoton("Medicamentos", 170);
            crearBoton("Proveedores", 220);
            crearBoton("Personal", 270);
            crearBoton("Inventario", 320);
            crearBoton("Entradas", 370);
            crearBoton("Salidas", 420);
            crearBoton("Reportes", 470);

            Button cerrar = new Button();
            cerrar.Text = "Cerrar sesión";
            cerrar.Location = new Point(20, 560);
            cerrar.Size = new Size(180, 40);
            cerrar.BackColor = Color.FromArgb(190, 65, 65);
            cerrar.ForeColor = Color.White;
            cerrar.FlatStyle = FlatStyle.Flat;
            cerrar.FlatAppearance.BorderSize = 0;
            cerrar.Click += (s, e) => this.Close();
            lateral.Controls.Add(cerrar);

            contenido = new Panel();
            contenido.Location = new Point(220, 0);
            contenido.Size = new Size(780, 800);
            contenido.BackColor = Color.FromArgb(242, 245, 249);
            this.Controls.Add(contenido);

            titulo = new Label();
            titulo.Text = "Sistema de Farmacia";
            titulo.Font = new Font("Segoe UI", 22, FontStyle.Bold);
            titulo.ForeColor = Color.FromArgb(30, 55, 85);
            titulo.Location = new Point(35, 35);
            titulo.AutoSize = true;
            contenido.Controls.Add(titulo);

            subtitulo = new Label();
            subtitulo.Text = "Sistema de gestión de farmacia";
            subtitulo.Font = new Font("Segoe UI", 11);
            subtitulo.ForeColor = Color.Gray;
            subtitulo.Location = new Point(38, 80);
            subtitulo.AutoSize = true;
            contenido.Controls.Add(subtitulo);

            Label info = new Label();
            info.Text = "A continuación se presenta un sistema con conexión de base de datos para una\n farmacia asi bien chila";
            info.Font = new Font("Segoe UI", 12);
            info.ForeColor = Color.FromArgb(90, 105, 120);
            info.Location = new Point(38, 150);
            info.AutoSize = true;
            contenido.Controls.Add(info);
        }

        private void crearBoton(string texto, int y)
        {
            Button boton = new Button();
            boton.Text = texto;
            boton.Location = new Point(15, y);
            boton.Size = new Size(190, 40);
            boton.BackColor = Color.FromArgb(84, 171, 186);
            boton.ForeColor = Color.White;
            boton.FlatStyle = FlatStyle.Flat;
            boton.FlatAppearance.BorderSize = 0;
            boton.Font = new Font("Segoe UI", 10);
            boton.TextAlign = ContentAlignment.MiddleLeft;
            boton.Padding = new Padding(15, 0, 0, 0);
            boton.Cursor = Cursors.Hand;

            botones.Add(texto, boton);

            boton.Click += (s, e) =>
            {
                if (texto == "Medicamentos")
                {
                    new Medicamentos(rol).ShowDialog();
                } else if (texto == "Proveedores")
                {
                    new Proveedores(rol).ShowDialog();
                } else if (texto == "Personal")
                {
                    new Personal(rol).ShowDialog();
                }
                else if (texto == "Inventario")
                {
                    new Inventario(rol).ShowDialog();
                } else if (texto == "Entradas")
                {
                    new Entradas(rol).ShowDialog();
                }
                else if (texto == "Salidas")
                {
                    new Salidas(rol).ShowDialog();
                }
                else if (texto == "Reportes")
                {
                    //new Reportes(rol).ShowDialog();
                }
                else
                {
                    titulo.Text = texto;
                    subtitulo.Text = "Módulo de " + texto.ToLower();

                    MessageBox.Show(
                        "El módulo de " + texto + " estará disponible próximamente.",
                        "FarmaBase",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
            };

            lateral.Controls.Add(boton);
        }

        private void aplicarPermisos()
        {
            foreach (Button boton in botones.Values)
            {
                boton.Enabled = false;
            }

            if (rol == "Administrador")
            {
                foreach (Button boton in botones.Values)
                {
                    boton.Enabled = true;
                }
            }
            else if (rol == "Encargado")
            {
                botones["Medicamentos"].Enabled = true;
                botones["Proveedores"].Enabled = true;
                botones["Personal"].Enabled = true;
                botones["Inventario"].Enabled = true;
                botones["Entradas"].Enabled = true;
                botones["Salidas"].Enabled = true;
                botones["Reportes"].Enabled = true;
            }
            else if (rol == "Consulta")
            {
                botones["Reportes"].Enabled = true;
            }
        }
    }
}