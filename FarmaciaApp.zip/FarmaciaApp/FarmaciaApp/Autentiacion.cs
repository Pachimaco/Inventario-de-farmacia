﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FarmaciaApp
{
    public class Autenticacion
    {
        public static string validarUsuario(string usuario, string password)
        {
            try
            {
                using (MySqlConnection cn = Conexion.obtenerConexion("Administrador"))
                {
                    cn.Open();

                    using (MySqlCommand cmd = new MySqlCommand("CALL farmacia.sp_login(@p_usuario)", cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@p_usuario", usuario);

                        using (MySqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.Read())
                            {
                                string clave = dr["password"].ToString();
                                string rol = dr["rol"].ToString();

                                MessageBox.Show(
                                    "Usuario encontrado: " + dr["usuario"] +
                                    "\nRol: " + rol
                                );

                                if (clave == password)
                                {
                                    return rol;
                                }
                            }
                            else
                            {
                                MessageBox.Show("El procedimiento no devolvió registros.");
                            }
                        }
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error de autenticación");
                return null;
            }
        }
    }
}