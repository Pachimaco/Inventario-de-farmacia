using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FarmaciaApp
{
    public partial class Login : Form
    {
        TextBox txtUsuario;
        TextBox txtPassword;
        Button btnLogin;
        public Login()
        {
            this.Text = "Farmacia";
            this.Size = new Size(400, 430);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.White;

            Label lblTitulo = new Label();
            lblTitulo.Text = "Farmacia";
            lblTitulo.Font = new Font("Arial", 22, FontStyle.Bold);
            lblTitulo.Size = new Size(300, 40);
            lblTitulo.Location = new Point(50, 40);
            lblTitulo.TextAlign = ContentAlignment.MiddleCenter;

            Label lblUsuario = new Label();
            lblUsuario.Text = "Usuario";
            lblUsuario.Font = new Font("Arial", 11);
            lblUsuario.Location = new Point(70, 120);
            lblUsuario.Size = new Size(250, 25);

            txtUsuario = new TextBox();
            txtUsuario.Font = new Font("Arial", 11);
            txtUsuario.Location = new Point(70, 150);
            txtUsuario.Size = new Size(250, 30);

            Label lblPassword = new Label();
            lblPassword.Text = "Contraseña";
            lblPassword.Font = new Font("Arial", 11);
            lblPassword.Location = new Point(70, 200);
            lblPassword.Size = new Size(250, 25);

            txtPassword = new TextBox();
            txtPassword.Font = new Font("Arial", 11);
            txtPassword.Location = new Point(70, 230);
            txtPassword.Size = new Size(250, 30);
            txtPassword.UseSystemPasswordChar = true;

            btnLogin = new Button();
            btnLogin.Text = "Iniciar sesión";
            btnLogin.Font = new Font("Arial", 11);
            btnLogin.Size = new Size(160, 40);
            btnLogin.Location = new Point(120, 300);
            btnLogin.BackColor = Color.LightGray;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Click += btnLogin_Click;

            this.Controls.Add(lblTitulo);
            this.Controls.Add(lblUsuario);
            this.Controls.Add(txtUsuario);
            this.Controls.Add(lblPassword);
            this.Controls.Add(txtPassword);
            this.Controls.Add(btnLogin);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text.Trim();
            string password = txtPassword.Text;

            if (usuario == "" || password == "")
            {
                MessageBox.Show("Ingresa tu usuario y contraseña.");
                return;
            }

            try
            {
                string rol = Autenticacion.validarUsuario(usuario, password);

                if (rol != null)
                {
                    MessageBox.Show("Bienvenido. Rol: " + rol);

                    Menu menu = new Menu(rol);
                    menu.FormClosed += (s, args) => this.Close();
                    menu.Show();

                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Usuario o contraseña incorrectos.");
                    txtPassword.Clear();
                    txtPassword.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error de inicio de sesión");
            }
        }
    }
}